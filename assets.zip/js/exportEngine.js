/**
 * exportEngine.js
 * ----------------------------------------------------------------------------
 * Dashboard export: PNG, multi-page PDF, summary Excel workbook, print, fullscreen.
 */
(function (global) {
  'use strict';

  const stamp = () => new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '');

  async function capture() {
    if (typeof html2canvas === 'undefined') throw new Error('html2canvas failed to load (check your internet connection).');
    const node = document.getElementById('dashboardRoot');
    document.body.classList.add('exporting');
    await new Promise((r) => setTimeout(r, 120));
    try {
      const bg = getComputedStyle(document.documentElement).getPropertyValue('--bg-solid').trim() || '#0b1b3a';
      return await html2canvas(node, { backgroundColor: bg, scale: Math.min(2, window.devicePixelRatio || 1.5), useCORS: true, logging: false, windowWidth: Math.max(document.documentElement.clientWidth, 1400), ignoreElements: (el) => el.classList && el.classList.contains('no-export') });
    } finally { document.body.classList.remove('exporting'); }
  }

  async function png() {
    const c = await capture();
    const a = document.createElement('a');
    a.href = c.toDataURL('image/png'); a.download = 'Sales_Dashboard_' + stamp() + '.png'; a.click();
  }

  async function pdf() {
    if (!global.jspdf) throw new Error('jsPDF failed to load (check your internet connection).');
    const c = await capture();
    const { jsPDF } = global.jspdf;
    const pw = 842, ph = 595;                                  // A4 landscape in pt
    const doc = new jsPDF({ orientation: 'landscape', unit: 'pt', format: 'a4' });
    const scale = pw / c.width;                                // fit width
    const sliceH = Math.floor(ph / scale);                     // source pixels per page
    let y = 0, page = 0;
    while (y < c.height) {
      const h = Math.min(sliceH, c.height - y);
      const part = document.createElement('canvas'); part.width = c.width; part.height = h;
      part.getContext('2d').drawImage(c, 0, y, c.width, h, 0, 0, c.width, h);
      if (page) doc.addPage();
      doc.addImage(part.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, pw, h * scale);
      y += h; page++;
    }
    doc.save('Sales_Dashboard_' + stamp() + '.pdf');
  }

  /** Summary workbook for the CURRENT filter selection */
  function excel(S) {
    if (typeof XLSX === 'undefined') throw new Error('SheetJS failed to load.');
    const k = S.k, g = S.g, wb = XLSX.utils.book_new();
    const add = (name, rows) => XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows.length ? rows : [{ Info: 'No data' }]), name);
    const grp = (arr, label) => KE.rank(KE.sortBy(arr, 'ach')).map((x) => ({
      Rank: x.rank, [label]: x.key, Sales: round(x.sales), Target: round(x.target), 'Achievement %': r1(x.ach), 'Gap To Target': round(x.gap),
      Forecast: round(x.forecast), 'Forecast Ach %': r1(x.fAch), 'Contribution %': r1(x.contrib), Invoices: x.invoices, Status: x.status.label
    }));
    add('KPIs', [
      ['Total Sales (GSV)', k.sales], ['Total Target', k.target], ['Achievement %', r1(k.ach)], ['Remaining To Target', k.remaining], ['Forecast Sales', k.forecast], ['Forecast Achievement %', r1(k.fAch)],
      ['Invoice Count', k.invoices], ['Order Count', k.orders], ['Active Customers', k.activeCust], ['Active Products', k.activeProd], ['Average Invoice Value', k.avgInvoice],
      ['Average Daily Sales', k.avgDaily], ['Required Daily Sales', k.reqDaily], ['Sales Run Rate', k.runRate], ['Reporting Month', k.ctx.label], ['Elapsed Days', k.ctx.elapsed], ['Total Days', k.ctx.totalDays],
      ['Forecast Confidence', k.confidence + '% (' + k.confLabel + ')']
    ].map((a) => ({ KPI: a[0], Value: typeof a[1] === 'number' ? round(a[1], 2) : a[1] })));
    add('Executives', grp(g.exec, 'KT Executive'));
    add('Supervisors', grp(g.sup, 'KT Supervisor'));
    add('KT Managers', grp(g.ktm, 'KT Manager'));
    add('KL Managers', grp(g.klm, 'KL Manager'));
    add('Divisions', grp(g.div, 'Division'));
    add('Customers', KE.rank(KE.sortBy(g.cust, 'sales')).map((x) => ({ Rank: x.rank, Customer: x.key, Sales: round(x.sales), 'Contribution %': r1(x.contrib), Invoices: x.invoices, 'Avg Invoice': round(x.avgInv), Target: round(x.target), 'Achievement %': r1(x.ach) })));
    add('Products', KE.rank(KE.sortBy(g.mat, 'sales')).map((x) => ({ Rank: x.rank, 'Material Code': x.code, Product: x.key, Division: x.div, Quantity: round(x.qty), Sales: round(x.sales), 'Contribution %': r1(x.contrib) })));
    add('Daily Sales', k.daily.labels.map((l, i) => ({ Date: l, GSV: k.daily.gsv[i] == null ? null : round(k.daily.gsv[i]), 'Moving Avg (7d)': k.daily.ma[i] == null ? null : round(k.daily.ma[i]), 'Forecast (run-rate)': k.daily.forecast[i] == null ? null : round(k.daily.forecast[i]) })));
    const fs = []; FE.DEFS.forEach((d) => FE.state.sets[d.key].forEach((v) => fs.push({ Filter: d.label, Value: v })));
    if (FE.state.from || FE.state.to) fs.unshift({ Filter: 'Invoice Date', Value: (FE.state.from ? DP.isoDate(FE.state.from) : '...') + ' to ' + (FE.state.to ? DP.isoDate(FE.state.to) : '...') });
    add('Filters Applied', fs.length ? fs : [{ Filter: 'None', Value: 'All data' }]);
    add('Validation', (S.warnings || []).map((w) => ({ Level: w.level, Message: w.msg, Count: w.count })));
    XLSX.writeFile(wb, 'Sales_Summary_' + stamp() + '.xlsx');
  }
  const round = (n, d) => (n == null || !isFinite(n) ? null : Math.round(n * Math.pow(10, d || 0)) / Math.pow(10, d || 0));
  const r1 = (n) => (n == null || !isFinite(n) ? null : Math.round(n * 10) / 10);

  /** Export any AG Grid's current rows (visible columns) to .xlsx using SheetJS */
  function gridToExcel(api, name) {
    const cols = api.getAllDisplayedColumns().filter((c) => c.getColDef().field);
    const data = [];
    api.forEachNodeAfterFilterAndSort((n) => {
      const o = {};
      cols.forEach((c) => { const d = c.getColDef(); o[d.headerName || d.field] = n.data[d.field]; });
      data.push(o);
    });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data.length ? data : [{ Info: 'No data' }]), 'Data');
    XLSX.writeFile(wb, name + '_' + stamp() + '.xlsx');
  }

  /** Downloads share-data.js (the dataset for a view-only copy of the dashboard). */
  function shareData(S) {
    const text = DP.toEmbedded(S.rows, S.meta, S.warnings);
    const blob = new Blob([text], { type: 'text/javascript' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = 'share-data.js'; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    return Math.round(text.length / 1024);
  }

  function print() { window.print(); }

  function fullscreen() {
    const d = document;
    if (!d.fullscreenElement) (d.documentElement.requestFullscreen || d.documentElement.webkitRequestFullscreen).call(d.documentElement);
    else (d.exitFullscreen || d.webkitExitFullscreen).call(d);
  }

  global.EX = { shareData, png, pdf, excel, gridToExcel, print, fullscreen };
})(window);
