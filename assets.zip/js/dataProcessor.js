/**
 * dataProcessor.js
 * ----------------------------------------------------------------------------
 * Upload parsing + data cleaning engine.
 *  - Reads .xlsx / .xls / .xlsb / .csv through SheetJS
 *  - Auto-detects the sheet and the header row (files often have title rows)
 *  - Maps columns by alias (English + Arabic template labels)
 *  - Normalises dates / numbers / text, removes empty + duplicate rows
 *  - Detects the Target layout (separate target rows, or repeated on invoices)
 *  - Produces validation warnings
 *
 * Row model produced (all modules use this):
 *  { id, inv, so, dt, ds, custCode, cust, div, matCode, mat, qty, gsv,
 *    exec, sup, ktm, klm, target, isTarget }
 *  dt = UTC midnight in ms (or null), ds = 'YYYY-MM-DD' (or null)
 */
(function (global) {
  'use strict';

  const DAY = 86400000;

  /** Canonical fields + accepted header aliases (normalised: lower-case, no spaces/punctuation). */
  const FIELDS = {
    inv:      { label: 'Invoice No',           req: false, alias: ['invoiceno', 'invoicenumber', 'invoice', 'invno', 'billingdocument', 'رقمالفاتوره', 'رقمالفاتورة'] },
    date:     { label: 'Invoice Date',         req: true,  alias: ['invoicedate', 'billingdate', 'date', 'invdate', 'تاريخالفاتوره', 'تاريخالفاتورة'] },
    so:       { label: 'SO No',                req: false, alias: ['sono', 'salesorderno', 'salesorder', 'ordernumber', 'orderno', 'رقمالاوردر'] },
    custCode: { label: 'Sold to Party Code',   req: false, alias: ['soldtopartycode', 'customercode', 'custcode', 'كودالعميلالرئيسي'] },
    cust:     { label: 'Sold to Party Name',   req: true,  alias: ['soldtopartyname', 'customername', 'customer', 'custname', 'اسمالعميلالرئيسي'] },
    div:      { label: 'Division Name',        req: true,  alias: ['divisionname', 'division', 'category', 'الكاتجري'] },
    matCode:  { label: 'Material Code',        req: false, alias: ['materialcode', 'sku', 'itemcode', 'productcode', 'كودالصنف'] },
    mat:      { label: 'Material Description', req: false, alias: ['materialdescription', 'materialname', 'product', 'itemdescription', 'productname', 'اسمالصنف'] },
    qty:      { label: 'Invoice Qty',          req: false, alias: ['invoiceqty', 'invoicequantity', 'quantity', 'qty', 'الكميه', 'الكمية'] },
    gsv:      { label: 'GSV',                  req: true,  alias: ['gsv', 'grosssalesvalue', 'sales', 'amount', 'اجماليسعرالصنفداخلالفاتوره'] },
    exec:     { label: 'KT Executive',         req: true,  alias: ['ktexecutive', 'executive', 'salesrep', 'salesexecutive', 'اسمالمندوب'] },
    sup:      { label: 'KT Supervisor',        req: false, alias: ['ktsupervisor', 'supervisor', 'اسمالمشرف'] },
    ktm:      { label: 'KT Manager',           req: false, alias: ['ktmanager', 'salesmanager', 'مديرالبيع'] },
    klm:      { label: 'KL Manager',           req: false, alias: ['klmanager', 'مديرالبيعلشركهمارس'] },
    target:   { label: 'Target',               req: false, alias: ['target', 'salestarget', 'التارجت'] }
  };

  const norm = (s) => String(s == null ? '' : s).toLowerCase().replace(/[\s_\-\.\/\\()]+/g, '').replace(/[^a-z0-9؀-ۿ]/g, '');

  const aliasIndex = {};
  Object.keys(FIELDS).forEach((k) => FIELDS[k].alias.forEach((a) => { aliasIndex[norm(a)] = k; }));
  Object.keys(FIELDS).forEach((k) => { aliasIndex[norm(FIELDS[k].label)] = k; });

  /* ------------------------------------------------------------------ */
  /* Value normalisers                                                    */
  /* ------------------------------------------------------------------ */
  const ARABIC_DIGITS = /[٠-٩۰-۹]/g;
  function westernDigits(s) {
    return s.replace(ARABIC_DIGITS, (d) => { const c = d.charCodeAt(0); return String(c >= 0x06F0 ? c - 0x06F0 : c - 0x0660); });
  }

  /** @returns {number|null|NaN}  null = blank, NaN = invalid text */
  function toNumber(v) {
    if (v == null || v === '') return null;
    if (typeof v === 'number') return isFinite(v) ? v : NaN;
    if (typeof v === 'boolean') return NaN;
    let s = westernDigits(String(v)).trim();
    if (s === '' || s === '-' || s === '--') return null;
    let neg = false;
    if (/^\(.*\)$/.test(s)) { neg = true; s = s.slice(1, -1); }
    s = s.replace(/[\s,٬ ]/g, '').replace(/[^\d.\-eE+%]/g, '');
    if (s.endsWith('-')) { neg = !neg; s = s.slice(0, -1); }
    if (s === '' ) return NaN;
    const n = Number(s.replace('%', ''));
    if (!isFinite(n)) return NaN;
    return neg ? -n : n;
  }

  const txt = (v) => (v == null ? '' : String(v).replace(/\s+/g, ' ').trim());

  /** Excel serial -> UTC midnight ms */
  function serialToMs(n) { return Math.floor(n - 25569) * DAY; }

  function ymdToMs(y, m, d) {
    if (y < 100) y += 2000;
    const t = Date.UTC(y, m - 1, d);
    const dt = new Date(t);
    return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d ? t : null;
  }

  /** Decide whether slash dates are D/M/Y or M/D/Y by scanning the column. */
  function detectDateOrder(values) {
    let dmy = 0, mdy = 0;
    for (let i = 0; i < values.length; i++) {
      const v = values[i];
      if (typeof v !== 'string') continue;
      const m = westernDigits(v).trim().match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/);
      if (!m) continue;
      if (+m[1] > 12) dmy++;
      if (+m[2] > 12) mdy++;
    }
    return dmy > mdy ? 'DMY' : 'MDY';
  }

  function toDate(v, order) {
    if (v == null || v === '') return null;
    if (v instanceof Date) return isNaN(v) ? NaN : Date.UTC(v.getFullYear(), v.getMonth(), v.getDate());
    if (typeof v === 'number') return v > 20000 && v < 80000 ? serialToMs(v) : NaN;
    let s = westernDigits(String(v)).trim();
    if (!s) return null;
    if (/^\d{5}(\.\d+)?$/.test(s)) return serialToMs(Number(s));
    let m = s.match(/^(\d{4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})/);
    if (m) { const t = ymdToMs(+m[1], +m[2], +m[3]); return t == null ? NaN : t; }
    m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/);
    if (m) {
      const a = +m[1], b = +m[2], y = +m[3];
      const t = order === 'DMY' ? ymdToMs(y, b, a) : ymdToMs(y, a, b);
      return t == null ? NaN : t;
    }
    const p = Date.parse(s);
    if (!isNaN(p)) { const d = new Date(p); return Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()); }
    return NaN;
  }

  const isoDate = (ms) => new Date(ms).toISOString().slice(0, 10);

  /* ------------------------------------------------------------------ */
  /* Reading files                                                        */
  /* ------------------------------------------------------------------ */
  function readFileAsync(file) {
    return new Promise((resolve, reject) => {
      const fr = new FileReader();
      const isCsv = /\.csv$/i.test(file.name);
      fr.onerror = () => reject(new Error('Unable to read the file from disk.'));
      fr.onload = () => resolve(fr.result);
      if (isCsv) fr.readAsText(file, 'utf-8'); else fr.readAsArrayBuffer(file);
    });
  }

  /** Find best sheet + header row. Scans first 40 rows of each sheet. */
  function locateTable(wb) {
    let best = null;
    wb.SheetNames.forEach((name) => {
      const ws = wb.Sheets[name];
      if (!ws || !ws['!ref']) return;
      const ref = XLSX.utils.decode_range(ws['!ref']);
      const scan = XLSX.utils.sheet_to_json(ws, {
        header: 1, raw: true, blankrows: false,
        range: { s: { r: ref.s.r, c: ref.s.c }, e: { r: Math.min(ref.e.r, ref.s.r + 39), c: ref.e.c } }
      });
      for (let r = 0; r < scan.length; r++) {
        const row = scan[r] || [];
        const hit = new Set();
        row.forEach((c) => { const k = aliasIndex[norm(c)]; if (k) hit.add(k); });
        const score = hit.size;
        if (!best || score > best.score) best = { name, score, headerOffset: r, startRow: ref.s.r, ref };
      }
    });
    return best;
  }

  /**
   * Parse the uploaded file.
   * @returns {Promise<{rows:Array, warnings:Array, meta:Object}>}
   */
  async function parseFile(file) {
    if (!/\.(xlsx|xls|xlsb|xlsm|csv|ods)$/i.test(file.name)) {
      throw new Error('Unsupported file type. Please upload .xlsx, .xls, .xlsb or .csv');
    }
    if (typeof XLSX === 'undefined') throw new Error('SheetJS library failed to load (check your internet connection).');
    const data = await readFileAsync(file);
    const isCsv = /\.csv$/i.test(file.name);
    let wb;
    try {
      wb = isCsv ? XLSX.read(String(data).replace(/^﻿/, ''), { type: 'string', raw: true })
                 : XLSX.read(data, { type: 'array', cellDates: false, dense: false });
    } catch (e) { throw new Error('The file could not be opened - it may be corrupted or password protected. (' + e.message + ')'); }

    const loc = locateTable(wb);
    if (!loc || loc.score < 3) {
      throw new Error('No sales table found. The sheet must contain headers such as Invoice Date, Sold to Party Name, Division Name, GSV, KT Executive.');
    }
    const ws = wb.Sheets[loc.name];
    const headerRowIdx = loc.startRow + loc.headerOffset;
    const matrix = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, blankrows: false, defval: null, range: headerRowIdx });
    const headers = matrix[0] || [];
    const colMap = {};
    headers.forEach((h, i) => { const k = aliasIndex[norm(h)]; if (k && colMap[k] == null) colMap[k] = i; });

    const result = clean(matrix.slice(1), colMap, { sheet: loc.name, headerRow: headerRowIdx + 1, fileName: file.name, headerCount: headers.length });
    return result;
  }

  /* ------------------------------------------------------------------ */
  /* Cleaning                                                             */
  /* ------------------------------------------------------------------ */
  function clean(dataRows, colMap, metaIn, opts) {
    opts = opts || {};
    const warnings = [];
    const warn = (level, code, msg, count) => warnings.push({ level, code, msg, count: count || 0 });

    // Column validation
    const missingReq = [], missingOpt = [];
    Object.keys(FIELDS).forEach((k) => {
      if (colMap[k] == null) (FIELDS[k].req ? missingReq : missingOpt).push(FIELDS[k].label);
    });
    if (missingReq.length) {
      const err = new Error('Required column(s) missing: ' + missingReq.join(', ') + '.');
      err.missing = missingReq; throw err;
    }
    if (missingOpt.length) warn('warning', 'MISSING_COLUMNS', 'Optional column(s) not found, related visuals use fallbacks: ' + missingOpt.join(', '), missingOpt.length);

    const col = (k) => colMap[k];
    const get = (row, k) => (colMap[k] == null ? null : row[colMap[k]]);

    // Detect date order
    const sample = [];
    const step = Math.max(1, Math.floor(dataRows.length / 3000));
    for (let i = 0; i < dataRows.length; i += step) sample.push(get(dataRows[i], 'date'));
    const order = detectDateOrder(sample);

    const stats = { src: dataRows.length, empty: 0, badDate: 0, badGsv: 0, badQty: 0, badTarget: 0, noCust: 0, blankTarget: 0, dup: 0, noDateInvoice: 0 };
    let rows = [];
    let seq = 0;

    for (let i = 0; i < dataRows.length; i++) {
      const raw = dataRows[i];
      if (!raw || !raw.length) { stats.empty++; continue; }

      const inv = txt(get(raw, 'inv'));
      let gsv = toNumber(get(raw, 'gsv'));
      let qty = toNumber(get(raw, 'qty'));
      let tgt = toNumber(get(raw, 'target'));
      const dtv = toDate(get(raw, 'date'), order);

      if (Number.isNaN(gsv)) { stats.badGsv++; gsv = null; }
      if (Number.isNaN(qty)) { stats.badQty++; qty = null; }
      if (Number.isNaN(tgt)) { stats.badTarget++; tgt = null; }

      const hasSales = gsv != null || qty != null || inv !== '';
      const hasTarget = tgt != null;
      if (!hasSales && !hasTarget) { stats.empty++; continue; }   // empty row (e.g. blank target placeholders)

      let dt = null, ds = null;
      if (Number.isNaN(dtv)) { stats.badDate++; }
      else if (dtv != null) { dt = dtv; ds = isoDate(dtv); }
      if (hasSales && dt == null && !Number.isNaN(dtv)) stats.noDateInvoice++;

      let cust = txt(get(raw, 'cust'));
      if (!cust) { stats.noCust++; cust = 'Unknown Customer'; }

      rows.push({
        id: ++seq,
        inv: inv || null,
        so: txt(get(raw, 'so')) || null,
        dt, ds,
        custCode: txt(get(raw, 'custCode')) || null,
        cust,
        div: txt(get(raw, 'div')) || 'Unknown Division',
        matCode: txt(get(raw, 'matCode')) || null,
        mat: txt(get(raw, 'mat')) || (hasSales ? '(No Description)' : null),
        qty: qty || 0,
        gsv: gsv || 0,
        exec: txt(get(raw, 'exec')) || '(Unassigned)',
        sup: txt(get(raw, 'sup')) || '(Unassigned)',
        ktm: txt(get(raw, 'ktm')) || '(Unassigned)',
        klm: txt(get(raw, 'klm')) || '(Unassigned)',
        target: tgt || 0,
        _hasSales: hasSales,
        _hasTarget: hasTarget
      });
    }

    // ---- Target layout detection -----------------------------------
    const withTarget = rows.filter((r) => r._hasTarget && r.target > 0);
    const attached = withTarget.filter((r) => r._hasSales).length;
    let targetMode = 'separate';
    if (withTarget.length && attached / withTarget.length > 0.3) {
      // Target repeated on invoice lines: take ONE value per Executive+Customer+Division.
      targetMode = 'attached';
      const seen = new Map();
      rows.forEach((r) => {
        if (r._hasTarget && r.target > 0) {
          const k = r.exec + '|' + r.cust + '|' + r.div;
          if (!seen.has(k)) seen.set(k, { exec: r.exec, sup: r.sup, ktm: r.ktm, klm: r.klm, cust: r.cust, custCode: r.custCode, div: r.div, target: r.target });
        }
        r.target = 0; r._hasTarget = false;
      });
      seen.forEach((t) => rows.push({ id: ++seq, inv: null, so: null, dt: null, ds: null, custCode: t.custCode, cust: t.cust, div: t.div,
        matCode: null, mat: null, qty: 0, gsv: 0, exec: t.exec, sup: t.sup, ktm: t.ktm, klm: t.klm, target: t.target, _hasSales: false, _hasTarget: true }));
      warn('info', 'TARGET_ATTACHED', 'Target values were repeated on invoice lines. They were counted once per Executive + Customer + Division to avoid double counting.', seen.size);
    }

    // ---- Duplicates (identical in every field) ------------------------
    if (opts.removeDuplicates !== false) {
      const keys = new Set();
      const out = [];
      rows.forEach((r) => {
        const k = [r.inv, r.so, r.ds, r.custCode, r.cust, r.div, r.matCode, r.mat, r.qty, r.gsv, r.exec, r.sup, r.ktm, r.klm, r.target].join('\u0001');
        if (keys.has(k)) { stats.dup++; return; }
        keys.add(k); out.push(r);
      });
      rows = out;
    }

    // mark rows
    rows.forEach((r) => { r.isTarget = !r._hasSales && r._hasTarget; delete r._hasSales; delete r._hasTarget; });
    // target rows must not carry sales
    rows.forEach((r) => { if (r.isTarget) { r.gsv = 0; r.qty = 0; } });

    // ---- Warnings ---------------------------------------------------------
    if (stats.empty) warn('info', 'EMPTY_ROWS', 'Empty / placeholder rows removed (no invoice, GSV, quantity or target).', stats.empty);
    if (stats.dup) warn('warning', 'DUPLICATES', 'Exact duplicate rows removed.', stats.dup);
    if (stats.badDate) warn('warning', 'INVALID_DATES', 'Invalid Invoice Date values were found; those invoices are excluded whenever a date filter is applied.', stats.badDate);
    if (stats.badGsv) warn('warning', 'INVALID_GSV', 'Non-numeric GSV values were treated as 0.', stats.badGsv);
    if (stats.badQty) warn('warning', 'INVALID_QTY', 'Non-numeric Invoice Qty values were treated as 0.', stats.badQty);
    if (stats.badTarget) warn('warning', 'INVALID_TARGET', 'Non-numeric Target values were treated as blank.', stats.badTarget);
    if (stats.noCust) warn('warning', 'MISSING_CUSTOMER', 'Rows without a customer name were labelled "Unknown Customer".', stats.noCust);
    const neg = rows.filter((r) => !r.isTarget && r.gsv < 0).length;
    if (neg) warn('info', 'NEGATIVE_GSV', 'Negative GSV lines (returns / credit notes) are kept and reduce net sales.', neg);
    const zeroT = rows.filter((r) => r.isTarget && r.target === 0).length;
    if (zeroT) warn('info', 'ZERO_TARGET', 'Target rows with a zero target were kept (blank targets count as 0).', zeroT);
    const hasInv = rows.some((r) => !r.isTarget);
    if (!hasInv) warn('error', 'NO_SALES', 'No sales (invoice) rows were found after cleaning.', 0);
    if (!rows.some((r) => r.isTarget || r.target > 0)) warn('warning', 'NO_TARGET', 'No target values found - achievement metrics will show as N/A.', 0);

    const dts = rows.filter((r) => r.dt != null).map((r) => r.dt);
    let minDt = null, maxDt = null;
    for (let i = 0; i < dts.length; i++) { if (minDt == null || dts[i] < minDt) minDt = dts[i]; if (maxDt == null || dts[i] > maxDt) maxDt = dts[i]; }
    if (minDt != null) {
      const months = new Set(dts.map((t) => isoDate(t).slice(0, 7)));
      if (months.size > 1) warn('info', 'MULTI_MONTH', 'Data spans ' + months.size + ' months. Forecast / pace metrics use the latest month; use the date filter to focus on a month.', months.size);
    }

    return {
      rows, warnings, stats,
      meta: Object.assign({}, metaIn, { colMap, targetMode, dateOrder: order, minDt, maxDt, sourceRows: stats.src, cleanRows: rows.length, loadedAt: new Date() })
    };
  }

  /* ------------------------------------------------------------------ */
  /* Demo data + template                                                 */
  /* ------------------------------------------------------------------ */
  function seeded(seed) { let s = seed; return () => (s = (s * 16807) % 2147483647) / 2147483647; }

  function buildDemoRows() {
    const rnd = seeded(42);
    const divs = ['MASS FOOD', 'PRINGLE', 'KELLOG CEREALS', 'KT NOODLES'];
    const prods = { 'MASS FOOD': ['Cheese Spread 140g', 'Tuna Light 185g', 'Ketchup 340g', 'Mayo 400ml', 'Corn Flakes Pack'], 'PRINGLE': ['Original 165g', 'Sour Cream 165g', 'BBQ 165g', 'Paprika 110g'], 'KELLOG CEREALS': ['Froot Loops 375g', 'Corn Flakes 500g', 'Coco Pops 350g'], 'KT NOODLES': ['Chicken Noodles 70g', 'Beef Noodles 70g', 'Spicy Noodles 75g', 'Cup Noodles 60g'] };
    const execs = [['Adham', 'Mohamed Said', 'Amr AbdelGalil', 'Abdelrahman Wahba'], ['Youssef', 'Mohamed Said', 'Amr AbdelGalil', 'Abdelrahman Wahba'], ['Shehab', 'Nour Hany', 'Ahmed Sayed', 'Omar Gomaa'], ['Karim Saad', 'Nour Hany', 'Ahmed Sayed', 'Omar Gomaa'], ['Mahmoud Samy', 'Tarek Fouad', 'Sherif Selim', 'Mahmoud Saad'], ['Hazem Ayman', 'Tarek Fouad', 'Sherif Selim', 'Mahmoud Saad']];
    const custs = ['ARAFA', 'EL FERGANY', 'Carrefour Maadi', 'Spinneys', 'Metro Market', 'Gomla Market', 'Seoudi', 'Fathalla', 'Ragab Sons', 'Oscar', 'Zaher', 'Hyper One'];
    const rows = [];
    const raw = [];
    let inv = 900000;
    const today = new Date(); const y = today.getFullYear(), m = today.getMonth();
    const elapsed = Math.max(5, Math.min(today.getDate(), 24));
    custs.forEach((c, ci) => {
      const e = execs[ci % execs.length];
      divs.forEach((d) => {
        raw.push([null, null, null, null, c, d, null, null, null, null, e[0], e[1], e[2], e[3], Math.round((60000 + rnd() * 240000) / 5000) * 5000]);
        const n = 20 + Math.floor(rnd() * 40);
        for (let i = 0; i < n; i++) {
          const day = 1 + Math.floor(rnd() * elapsed);
          const p = prods[d][Math.floor(rnd() * prods[d].length)];
          const q = 1 + Math.floor(rnd() * 40);
          const price = 20 + rnd() * 90;
          raw.push([++inv, new Date(Date.UTC(y, m, day)), 5000 + Math.floor(inv / 3), 1000 + ci, c, d, 'M' + (100 + (p.length * 7) % 900), p, q, Math.round(q * price * (rnd() < 0.03 ? -1 : 1) * 100) / 100, e[0], e[1], e[2], e[3], null]);
        }
      });
    });
    return raw;
  }

  function demo() {
    const map = {}; const order = ['inv', 'date', 'so', 'custCode', 'cust', 'div', 'matCode', 'mat', 'qty', 'gsv', 'exec', 'sup', 'ktm', 'klm', 'target'];
    order.forEach((k, i) => { map[k] = i; });
    return clean(buildDemoRows(), map, { sheet: 'Demo', headerRow: 1, fileName: 'Demo data (generated)' });
  }

  function downloadTemplate() {
    const head = Object.keys(FIELDS).map((k) => FIELDS[k].label);
    const ws = XLSX.utils.aoa_to_sheet([head, ['INV-1001', '2026-11-01', 'SO-1', 'C001', 'Customer A', 'MASS FOOD', 'M100', 'Product X', 10, 1500, 'Executive 1', 'Supervisor 1', 'KT Manager 1', 'KL Manager 1', ''],
      [null, null, null, null, 'Customer A', 'MASS FOOD', null, null, null, null, 'Executive 1', 'Supervisor 1', 'KT Manager 1', 'KL Manager 1', 100000]]);
    const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, 'Sales');
    XLSX.writeFile(wb, 'Sales_Dashboard_Template.xlsx');
  }

  /* ------------------------------------------------------------------ */
  /* Share / view-only support: compact embed of the cleaned dataset       */
  /* ------------------------------------------------------------------ */
  /** Encode cleaned rows into the text of a `share-data.js` file. Strings are dictionary-encoded to keep it small. */
  function toEmbedded(rows, meta, warnings) {
    const dict = [], idx = new Map();
    const sid = (v) => { if (v == null) return -1; let i = idx.get(v); if (i == null) { i = dict.length; dict.push(v); idx.set(v, i); } return i; };
    const out = rows.map((r) => [sid(r.inv), sid(r.so), r.dt, sid(r.custCode), sid(r.cust), sid(r.div), sid(r.matCode), sid(r.mat), r.qty, r.gsv, sid(r.exec), sid(r.sup), sid(r.ktm), sid(r.klm), r.target, r.isTarget ? 1 : 0]);
    const payload = { v: 1, builtAt: new Date().toISOString(),
      meta: { fileName: meta.fileName, sheet: meta.sheet, minDt: meta.minDt, maxDt: meta.maxDt, sourceRows: meta.sourceRows, cleanRows: meta.cleanRows, targetMode: meta.targetMode, dateOrder: meta.dateOrder },
      warnings, dict, rows: out };
    return 'window.SD_EMBEDDED=' + JSON.stringify(payload) + ';';
  }

  function fromEmbedded(p) {
    const d = p.dict, g = (i) => (i < 0 ? null : d[i]);
    const rows = p.rows.map((a, n) => ({
      id: n + 1, inv: g(a[0]), so: g(a[1]), dt: a[2], ds: a[2] == null ? null : isoDate(a[2]), custCode: g(a[3]), cust: g(a[4]), div: g(a[5]),
      matCode: g(a[6]), mat: g(a[7]), qty: a[8], gsv: a[9], exec: g(a[10]), sup: g(a[11]), ktm: g(a[12]), klm: g(a[13]), target: a[14], isTarget: a[15] === 1
    }));
    return { rows, warnings: p.warnings || [], meta: Object.assign({}, p.meta, { loadedAt: new Date(p.builtAt) }) };
  }

  global.DP = { FIELDS, parseFile, clean, demo, downloadTemplate, toNumber, toDate, isoDate, toEmbedded, fromEmbedded, DAY };
})(window);
