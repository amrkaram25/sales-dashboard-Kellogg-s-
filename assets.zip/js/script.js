/**
 * script.js  -  Application controller
 * ----------------------------------------------------------------------------
 * Wires the upload engine, filter engine, KPI engine, charts, AG Grid tables,
 * DataTables, exports, theme, notifications and error handling together.
 *
 * Flow:  file -> DP.parseFile -> App.load -> FE.init -> App.refresh
 *        filter change -> FE.apply -> KE.compute/group -> render everything
 */
(function () {
  'use strict';

  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* ======================================================================
   * UI helpers: toast, loader, theme
   * ==================================================================== */
  const UI = {
    toast(type, msg, ms) {
      const icons = { success: 'bi-check-circle-fill', danger: 'bi-x-octagon-fill', warning: 'bi-exclamation-triangle-fill', info: 'bi-info-circle-fill' };
      const t = type === 'error' ? 'danger' : type;
      const el = document.createElement('div');
      el.className = `toast align-items-center border-0 toast-${t}`;
      el.setAttribute('role', 'alert');
      el.innerHTML = `<div class="d-flex"><div class="toast-body"><i class="bi ${icons[t] || icons.info} me-2"></i>${msg}</div><button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
      $('#toastHost').appendChild(el);
      const bt = new bootstrap.Toast(el, { delay: ms || (t === 'danger' ? 8000 : 4500) });
      el.addEventListener('hidden.bs.toast', () => el.remove());
      bt.show();
    },
    loading(on, msg) { $('#loader').classList.toggle('show', !!on); if (msg) $('#loaderMsg').textContent = msg; },
    theme(name) {
      document.documentElement.setAttribute('data-theme', name);
      try { localStorage.setItem('sd-theme', name); } catch (e) { /* storage unavailable */ }
      $('#btnTheme i').className = 'bi ' + (name === 'dark' ? 'bi-sun-fill' : 'bi-moon-stars-fill');
      $$('.grid-host').forEach((g) => { g.classList.remove('ag-theme-alpine', 'ag-theme-alpine-dark'); g.classList.add(name === 'dark' ? 'ag-theme-alpine-dark' : 'ag-theme-alpine'); });
    }
  };
  window.UI = UI;

  /* ======================================================================
   * State
   * ==================================================================== */
  const S = { viewOnly: false, rows: [], meta: null, warnings: [], filtered: [], k: null, g: null, rankBy: 'ach', prodMode: 'sales', loaded: false };
  window.SD = S;
  const grids = {};

  /* ======================================================================
   * Upload engine
   * ==================================================================== */
  async function handleFile(file) {
    if (!file || S.viewOnly) return;   // uploads are disabled in the shared view-only copy
    $('#uploadError').classList.add('d-none');
    UI.loading(true, 'Reading ' + file.name + '…');
    await new Promise((r) => setTimeout(r, 60));
    try {
      const res = await DP.parseFile(file);
      UI.loading(true, 'Building dashboard…');
      await new Promise((r) => setTimeout(r, 30));
      load(res);
      UI.toast('success', `<b>${esc(file.name)}</b> loaded - ${FMT.num(res.rows.length)} rows processed.`);
    } catch (e) {
      console.error(e);
      const box = $('#uploadError');
      box.innerHTML = `<i class="bi bi-x-octagon-fill me-2"></i><b>Upload failed.</b> ${esc(e.message)}` + (e.missing ? `<div class="small mt-1">Download the template to see the expected columns.</div>` : '');
      box.classList.remove('d-none');
      UI.toast('error', esc(e.message));
      if (S.loaded) { /* keep current dashboard */ } else $('#heroUpload').classList.remove('d-none');
    } finally { UI.loading(false); $('#fileInput').value = ''; }
  }

  function bindUpload() {
    const dz = $('#dropzone'), inp = $('#fileInput');
    $('#btnBrowse').onclick = (e) => { e.stopPropagation(); inp.click(); };
    $('#btnUpload').onclick = () => inp.click();
    dz.onclick = () => inp.click();
    inp.onchange = () => handleFile(inp.files[0]);
    ['dragenter', 'dragover'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add('drag'); }));
    ['dragleave', 'drop'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove('drag'); }));
    dz.addEventListener('drop', (e) => handleFile(e.dataTransfer.files[0]));

    // Whole-window drop (replace file when dashboard already loaded)
    let depth = 0; const ov = $('#dropOverlay');
    window.addEventListener('dragenter', (e) => { if (!S.loaded || S.viewOnly || !e.dataTransfer || !Array.from(e.dataTransfer.types || []).includes('Files')) return; depth++; ov.classList.add('show'); });
    window.addEventListener('dragleave', () => { if (!S.loaded) return; depth = Math.max(0, depth - 1); if (!depth) ov.classList.remove('show'); });
    window.addEventListener('dragover', (e) => e.preventDefault());
    window.addEventListener('drop', (e) => { e.preventDefault(); depth = 0; ov.classList.remove('show'); if (S.loaded && !S.viewOnly && e.dataTransfer.files.length && !e.target.closest('#dropzone')) handleFile(e.dataTransfer.files[0]); });

    $('#btnDemo').onclick = () => { UI.loading(true, 'Generating demo data…'); setTimeout(() => { try { load(DP.demo()); UI.toast('info', 'Demo data loaded - upload your own file any time.'); } catch (e) { UI.toast('error', e.message); } finally { UI.loading(false); } }, 40); };
    $$('.js-template').forEach((b) => (b.onclick = (e) => { e.preventDefault(); try { DP.downloadTemplate(); } catch (err) { UI.toast('error', err.message); } }));
  }

  /* ======================================================================
   * Load + refresh
   * ==================================================================== */
  function load(res) {
    S.rows = res.rows; S.meta = res.meta; S.warnings = res.warnings; S.loaded = true;
    $('#heroUpload').classList.add('d-none');
    $('#dash').classList.remove('d-none');
    $('#appHeaderActions').classList.remove('d-none');
    FE.init(S.rows, S.meta);
    FE.renderChips();
    renderFileInfo();
    renderValidation();
    refresh();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function refresh() {
    if (!S.loaded) return;
    const t0 = performance.now();
    try {
      S.filtered = FE.apply();
      S.k = KE.compute(S.filtered, S.meta);
      const tot = S.k.sales;
      S.g = {};
      FE.DEFS.forEach((d) => { S.g[d.key] = KE.group(S.filtered, d.field, S.k.ctx, tot); });
    } catch (e) { console.error(e); UI.toast('error', 'Calculation error: ' + esc(e.message)); return; }
    const safe = (n, fn) => { try { fn(); } catch (e) { console.error('[' + n + ']', e); UI.toast('warning', `Section "${n}" failed: ${esc(e.message)}`); } };
    safe('KPIs', renderKPIs);
    safe('Executive summary', renderSummary);
    safe('Traffic lights', renderTraffic);
    safe('Forecast engine', renderForecast);
    safe('Charts', () => CH.renderAll(S));
    safe('Gauge text', renderGaugeText);
    safe('Tables', renderGrids);
    safe('Analytics', renderAnalytics);
    $('#rowCount').textContent = FMT.num(S.filtered.filter((r) => !r.isTarget).length) + ' of ' + FMT.num(S.rows.filter((r) => !r.isTarget).length) + ' invoice lines';
    $('#ctxLabel').textContent = S.k.ctx.asOf ? `${S.k.ctx.label} · day ${S.k.ctx.elapsed}/${S.k.ctx.totalDays} · data as of ${DP.isoDate(S.k.ctx.asOf)}` : 'No dated sales in selection';
    const warnEl = $('#filterWarn');
    warnEl.classList.toggle('d-none', !(FE.state.sets.mat.size));
    console.debug('Dashboard refreshed in', Math.round(performance.now() - t0), 'ms');
  }

  /* ======================================================================
   * KPI cards
   * ==================================================================== */
  const prevVals = {};
  function renderKPIs() {
    const k = S.k, c = k.ctx;
    const noT = k.target <= 0;
    const defs = [
      { id: 'sales',   icon: 'bi-cash-stack',            label: 'Total Sales (GSV)',       v: k.sales,    f: 'compact', sub: FMT.num(k.sales) + ' net GSV' },
      { id: 'target',  icon: 'bi-bullseye',              label: 'Total Target',            v: k.target,   f: 'compact', sub: k.ach == null ? 'No target in selection' : `${FMT.compact(k.sales)} delivered` },
      { id: 'ach',     icon: 'bi-speedometer2',          label: 'Achievement %',           v: k.ach,      f: 'pct',     st: k.status, bar: k.ach, sub: k.status.label },
      { id: 'remain',  icon: 'bi-flag',                  label: 'Remaining To Target',     v: noT ? null : k.remaining, f: 'compact', st: noT ? null : (k.remaining <= 0 ? KE.STATUS.green : null), sub: noT ? 'N/A' : (k.remaining <= 0 ? 'Target exceeded' : `${c.remaining} day(s) left`) },
      { id: 'fsales',  icon: 'bi-graph-up-arrow',        label: 'Forecast Sales',          v: k.forecast, f: 'compact', sub: 'Month-end projection' },
      { id: 'fach',    icon: 'bi-bullseye',              label: 'Forecast Achievement %',  v: k.fAch,     f: 'pct',     st: k.fStatus, bar: k.fAch, sub: KE.FORECAST_LABEL[k.fStatus.key] },
      { id: 'inv',     icon: 'bi-receipt',               label: 'Invoice Count',           v: k.invoices, f: 'num',     sub: `${FMT.num(S.filtered.filter((r) => !r.isTarget).length)} lines` },
      { id: 'ord',     icon: 'bi-box2',                  label: 'Order Count',             v: k.orders,   f: 'num',     sub: 'Distinct SO numbers' },
      { id: 'cust',    icon: 'bi-people',                label: 'Active Customers',        v: k.activeCust, f: 'num',   sub: 'With net sales > 0' },
      { id: 'prod',    icon: 'bi-boxes',                 label: 'Active Products',         v: k.activeProd, f: 'num',   sub: 'SKUs sold' },
      { id: 'avginv',  icon: 'bi-receipt-cutoff',        label: 'Average Invoice Value',   v: k.avgInvoice, f: 'compact', sub: 'Sales ÷ distinct invoices' },
      { id: 'avgd',    icon: 'bi-calendar-day',          label: 'Average Daily Sales',     v: k.avgDaily, f: 'compact', sub: `Last 7 days: ${FMT.compact(k.last7Avg)}` },
      { id: 'reqd',    icon: 'bi-hourglass-split',       label: 'Required Daily Sales',    v: noT ? null : k.reqDaily, f: 'compact', sub: noT ? 'N/A' : (c.remaining ? `Over ${c.remaining} remaining day(s)` : 'Month closed') },
      { id: 'rr',      icon: 'bi-activity',              label: 'Sales Run Rate',          v: k.runRate,  f: 'compact', st: noT || !k.reqDaily ? null : (k.runRate >= k.reqDaily ? KE.STATUS.green : KE.status((k.runRate / k.reqDaily) * 100)), sub: noT || !k.reqDaily ? 'Per elapsed day' : `${FMT.pct((k.runRate / k.reqDaily) * 100, 0)} of required pace` }
    ];
    $('#kpiGrid').innerHTML = defs.map((d, i) => `
      <div class="kpi ${d.st ? 'st-' + d.st.key : ''}" style="animation-delay:${i * 35}ms" title="${esc(d.label)}">
        <div class="kpi-top"><span class="kpi-icon"><i class="bi ${d.icon}"></i></span><span class="kpi-label">${d.label}</span></div>
        <div class="kpi-val" data-id="${d.id}" data-raw="${d.v == null ? '' : d.v}" data-f="${d.f}">${fmtKpi(d.v, d.f)}</div>
        <div class="kpi-sub">${d.st ? '<span class="dot dot-' + d.st.key + '"></span>' : ''}${d.sub}</div>
        ${d.bar != null ? `<div class="kpi-bar"><i style="width:${Math.min(100, Math.max(0, d.bar))}%"></i></div>` : ''}
      </div>`).join('');
    $$('#kpiGrid .kpi-val').forEach((el) => countUp(el));
  }
  const fmtKpi = (v, f) => (v == null ? 'N/A' : f === 'pct' ? FMT.pct(v) : f === 'num' ? FMT.num(v) : FMT.compact(v));
  function countUp(el) {
    const raw = el.dataset.raw; if (raw === '') return;
    const to = Number(raw), id = el.dataset.id, from = prevVals[id] != null ? prevVals[id] : 0; prevVals[id] = to;
    const start = performance.now(), dur = 600;
    const step = (now) => { const p = Math.min(1, (now - start) / dur), e = 1 - Math.pow(1 - p, 3); el.textContent = fmtKpi(from + (to - from) * e, el.dataset.f); if (p < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step);
  }

  /* ======================================================================
   * Executive summary + traffic lights + gauge + forecast engine
   * ==================================================================== */
  function renderSummary() {
    const ins = KE.insights(S.k, S.g);
    const tile = (icon, label, g, metric, cls) => `
      <div class="ins ${cls || ''}"><div class="ins-ic"><i class="bi ${icon}"></i></div>
        <div class="ins-body"><div class="ins-label">${label}</div>
        <div class="ins-name" dir="auto" title="${esc(g ? g.key : '')}">${g ? esc(g.key) : '-'}</div>
        <div class="ins-metric">${g ? metric(g) : 'No data'}</div></div></div>`;
    const a = (g) => `${FMT.pct(g.ach)} · ${FMT.compact(g.sales)}`;
    $('#insightGrid').innerHTML = [
      tile('bi-trophy-fill', 'Best Performing Executive', ins.bestExec, a, 'good'),
      tile('bi-award-fill', 'Best Supervisor', ins.bestSup, a, 'good'),
      tile('bi-grid-fill', 'Best Category', ins.bestDiv, (g) => (g.ach != null ? a(g) : FMT.compact(g.sales)), 'good'),
      tile('bi-shop', 'Best Customer', ins.bestCust, (g) => `${FMT.compact(g.sales)} · ${FMT.pct(g.contrib)} share`, 'good'),
      tile('bi-box-seam-fill', 'Best Product', ins.bestProd, (g) => `${FMT.compact(g.sales)} · ${FMT.num(g.qty)} units`, 'good'),
      tile('bi-percent', 'Highest Achievement %', ins.highestAch, (g) => `<b>${FMT.pct(g.ach)}</b> of target`, 'good'),
      tile('bi-pie-chart-fill', 'Largest Sales Contribution', ins.topContrib, (g) => `<b>${FMT.pct(g.contrib)}</b> of total sales`),
      tile('bi-exclamation-diamond-fill', 'Largest Gap To Target', ins.gapExec, (g) => `Gap <b>${FMT.compact(g.gap)}</b> · ${FMT.pct(g.ach)}`, 'warn'),
      tile('bi-arrow-down-circle-fill', 'Worst Performer', ins.worst, a, 'bad')
    ].join('');
    $('#narrative').innerHTML = KE.narrative(S.k, ins, FMT).map((l) => `<li>${l}</li>`).join('');
  }

  function renderTraffic() {
    const k = S.k;
    const lights = ['green', 'yellow', 'orange', 'red'];
    const active = k.status.key;
    $('#trafficLights').innerHTML = lights.map((l) => `<div class="tl tl-${l} ${l === active ? 'on' : ''}" title="${KE.STATUS[l].label}"></div>`).join('') +
      `<div class="tl-text"><b>${k.status.label}</b><span>Overall · ${FMT.pct(k.ach)}</span></div>`;
    const ent = [['Executives', S.g.exec], ['Supervisors', S.g.sup], ['KT Managers', S.g.ktm], ['KL Managers', S.g.klm], ['Categories', S.g.div], ['Customers', S.g.cust]];
    $('#trafficTable').innerHTML = `<table class="tl-table"><thead><tr><th></th>${lights.map((l) => `<th><span class="dot dot-${l}"></span></th>`).join('')}</tr></thead><tbody>` +
      ent.map(([n, arr]) => { const c = { green: 0, yellow: 0, orange: 0, red: 0 }; arr.forEach((x) => { if (x.target > 0) c[x.status.key]++; }); return `<tr><td>${n}</td>${lights.map((l) => `<td class="${c[l] ? 'has' : ''}">${c[l]}</td>`).join('')}</tr>`; }).join('') +
      `</tbody></table><div class="tl-legend"><span><span class="dot dot-green"></span>Achieved ≥100%</span><span><span class="dot dot-yellow"></span>Near 90-99%</span><span><span class="dot dot-orange"></span>At risk 75-89%</span><span><span class="dot dot-red"></span>Critical &lt;75%</span></div>`;
  }

  function renderGaugeText() {
    const k = S.k;
    $('#gaugeVal').textContent = FMT.pct(k.ach);
    $('#gaugeVal').style.color = k.status.color;
    $('#gaugeStatus').innerHTML = `<span class="dot dot-${k.status.key}"></span>${k.status.label}` + (k.fAch != null ? ` <span class="gauge-fc">▲ Forecast ${FMT.pct(k.fAch)}</span>` : '');
  }

  function renderForecast() {
    const k = S.k, c = k.ctx;
    $('#fcSales').textContent = FMT.compact(k.forecast);
    $('#fcAch').textContent = FMT.pct(k.fAch); $('#fcAch').style.color = k.fStatus.color;
    $('#fcReq').textContent = k.target > 0 ? FMT.compact(k.reqDaily) : 'N/A';
    $('#fcReqSub').textContent = k.target > 0 ? `vs run-rate ${FMT.compact(k.runRate)}/day` : '';
    $('#fcGap').textContent = k.target > 0 ? FMT.compact(Math.abs(k.forecastGap)) : 'N/A';
    $('#fcGapLbl').textContent = k.forecastGap > 0 ? 'Forecast Gap To Target' : 'Forecast Surplus vs Target';
    $('#fcGap').style.color = k.target > 0 ? (k.forecastGap > 0 ? '#ef4444' : '#10b981') : '';
    $('#fcStatus').innerHTML = `<span class="dot dot-${k.fStatus.key}"></span>${KE.FORECAST_LABEL[k.fStatus.key]}`;
    $('#fcConfBar').style.width = k.confidence + '%';
    $('#fcConfBar').className = 'conf-fill ' + (k.confidence >= 70 ? 'hi' : k.confidence >= 45 ? 'mid' : 'lo');
    $('#fcConfTxt').textContent = `${k.confLabel} confidence (${k.confidence}%)`;
    $('#fcNote').textContent = `${c.label || ''} · ${c.elapsed} of ${c.totalDays} days elapsed · Forecast = (MTD sales ÷ elapsed days) × ${c.totalDays}`;

    const rows = S.g.div.slice().sort((a, b) => b.sales - a.sales).map((g) => [g.key, g.sales, g.target, g.forecast, g.fAch, g.reqDaily, g.fStatus.key]);
    if (!jQuery.fn || !jQuery.fn.DataTable) return;
    const dt = jQuery('#tblForecast');
    if (jQuery.fn.DataTable.isDataTable(dt)) dt.DataTable().destroy();
    dt.DataTable({
      data: rows, paging: false, searching: false, info: false, order: [[1, 'desc']], autoWidth: false,
      columns: [
        { title: 'Division', render: (d, t) => (t === 'display' ? `<span dir="auto">${esc(d)}</span>` : d) },
        { title: 'Sales', className: 'text-end', render: (d, t) => (t === 'display' ? FMT.num(d) : d) },
        { title: 'Target', className: 'text-end', render: (d, t) => (t === 'display' ? FMT.num(d) : d) },
        { title: 'Forecast', className: 'text-end', render: (d, t) => (t === 'display' ? FMT.num(d) : d) },
        { title: 'Fcst Ach %', className: 'text-end', render: (d, t) => (t === 'display' ? FMT.pct(d) : d == null ? -1 : d) },
        { title: 'Req / Day', className: 'text-end', render: (d, t) => (t === 'display' ? FMT.num(d) : d) },
        { title: 'Status', render: (d, t) => (t === 'display' ? `<span class="dot dot-${d}"></span>${KE.FORECAST_LABEL[d]}` : d) }
      ]
    });
  }

  /* ======================================================================
   * AG Grid tables
   * ==================================================================== */
  const pctCol = (field, name) => ({ headerName: name || 'Achievement %', field, type: 'numericColumn', width: 140, valueFormatter: (p) => FMT.pct(p.value), cellStyle: (p) => ({ color: KE.status(p.value).color, fontWeight: 700 }), comparator: (a, b) => (a == null ? -1 : a) - (b == null ? -1 : b) });
  const numCol = (field, name, w) => ({ headerName: name, field, type: 'numericColumn', width: w || 130, valueFormatter: (p) => FMT.num(p.value), filter: 'agNumberColumnFilter' });
  const statusCol = { headerName: 'Status', field: 'statusKey', width: 140, cellRenderer: (p) => `<span class="dot dot-${p.value}"></span>${KE.STATUS[p.value].label}` };
  const textCol = (field, name, w) => ({ headerName: name, field, flex: 1, minWidth: w || 160, cellClass: 'cell-auto', filter: 'agTextColumnFilter' });

  function ensureGrid(id, cols, extra) {
    if (grids[id]) return grids[id];
    const el = document.getElementById(id);
    el.classList.add(document.documentElement.getAttribute('data-theme') === 'dark' ? 'ag-theme-alpine-dark' : 'ag-theme-alpine');
    grids[id] = agGrid.createGrid(el, Object.assign({
      columnDefs: cols, rowData: [],
      defaultColDef: { sortable: true, filter: true, resizable: true, floatingFilter: true, minWidth: 90 },
      pagination: true, paginationPageSize: 15, paginationPageSizeSelector: [10, 15, 25, 50, 100],
      animateRows: true, suppressMovableColumns: false, enableCellTextSelection: true, tooltipShowDelay: 400
    }, extra || {}));
    return grids[id];
  }

  function renderGrids() {
    if (typeof agGrid === 'undefined') throw new Error('AG Grid library failed to load');
    // League table (executives)
    const execList = KE.rank(KE.sortBy(S.g.exec, S.rankBy)); const n = execList.length;
    const league = execList.map((g, i) => ({ rank: g.rank, exec: g.key, sales: g.sales, target: g.target, ach: g.ach, gap: g.gap, forecast: g.forecast, statusKey: g.status.key, _flag: i < 3 ? 'top' : (n > 3 && i >= n - 3 ? 'bottom' : '') }));
    const gl = ensureGrid('gridLeague', [
      { headerName: 'Rank', field: 'rank', width: 90, pinned: 'left', filter: 'agNumberColumnFilter', cellClass: 'rank-cell' },
      textCol('exec', 'KT Executive', 190), numCol('sales', 'Sales'), numCol('target', 'Target'), pctCol('ach'),
      Object.assign(numCol('gap', 'Gap'), { cellStyle: (p) => ({ color: p.value > 0 ? '#ef4444' : '#10b981', fontWeight: 600 }), headerTooltip: 'Target − Sales (positive = shortfall)' }),
      numCol('forecast', 'Forecast'), statusCol
    ], { getRowClass: (p) => (p.data._flag ? 'row-' + p.data._flag : '') });
    gl.setGridOption('rowData', league);

    // Customers
    const custList = KE.rank(KE.sortBy(S.g.cust, 'sales'));
    const gc = ensureGrid('gridCust', [
      { headerName: 'Rank', field: 'rank', width: 90, pinned: 'left', filter: 'agNumberColumnFilter' },
      textCol('name', 'Customer', 200), numCol('sales', 'Sales'),
      { headerName: 'Contribution %', field: 'contrib', type: 'numericColumn', width: 150, valueFormatter: (p) => FMT.pct(p.value), filter: 'agNumberColumnFilter' },
      numCol('invoices', 'Invoices', 110), numCol('avgInv', 'Avg Invoice'), numCol('target', 'Target'), pctCol('ach'), statusCol
    ]);
    gc.setGridOption('rowData', custList.map((g) => ({ rank: g.rank, name: g.key, sales: g.sales, contrib: g.contrib, invoices: g.invoices, avgInv: g.avgInv, target: g.target, ach: g.ach, statusKey: g.status.key })));

    // Products
    const prodList = KE.rank(KE.sortBy(S.g.mat, 'sales'));
    const gp = ensureGrid('gridProd', [
      { headerName: 'SKU Rank', field: 'rank', width: 110, pinned: 'left', filter: 'agNumberColumnFilter' },
      { headerName: 'Code', field: 'code', width: 120 }, textCol('name', 'Product', 220), { headerName: 'Division', field: 'div', width: 150 },
      numCol('qty', 'Quantity'), numCol('sales', 'Sales'),
      { headerName: 'Contribution %', field: 'contrib', type: 'numericColumn', width: 150, valueFormatter: (p) => FMT.pct(p.value), filter: 'agNumberColumnFilter' },
      { headerName: 'Avg Price', field: 'price', type: 'numericColumn', width: 120, valueFormatter: (p) => (p.value == null ? '-' : p.value.toFixed(2)) }
    ]);
    gp.setGridOption('rowData', prodList.map((g) => ({ rank: g.rank, code: g.code, name: g.key, div: g.div, qty: g.qty, sales: g.sales, contrib: g.contrib, price: g.qty ? g.sales / g.qty : null })));

    // Raw detail
    const gr = ensureGrid('gridRaw', [
      { headerName: 'Invoice No', field: 'inv', width: 130 }, { headerName: 'Date', field: 'ds', width: 120 }, { headerName: 'SO No', field: 'so', width: 120 },
      { headerName: 'Customer', field: 'cust', minWidth: 180, cellClass: 'cell-auto' }, { headerName: 'Division', field: 'div', width: 150 },
      { headerName: 'Material', field: 'mat', minWidth: 200, cellClass: 'cell-auto' }, numCol('qty', 'Qty', 90), numCol('gsv', 'GSV', 120), numCol('target', 'Target', 120),
      { headerName: 'KT Executive', field: 'exec', width: 150 }, { headerName: 'KT Supervisor', field: 'sup', width: 150 }, { headerName: 'KT Manager', field: 'ktm', width: 150 }, { headerName: 'KL Manager', field: 'klm', width: 150 }
    ], { paginationPageSize: 25 });
    gr.setGridOption('rowData', S.filtered);
  }

  /* ======================================================================
   * Customer / product analytics panels
   * ==================================================================== */
  function renderAnalytics() {
    const k = S.k;
    const mini = (label, val, sub) => `<div class="mini"><div class="mini-l">${label}</div><div class="mini-v">${val}</div><div class="mini-s">${sub || ''}</div></div>`;
    const list = (arr, valFn) => arr.length ? arr.map((g, i) => `<li><span class="rk">${g.rank || i + 1}</span><span class="nm" dir="auto" title="${esc(g.key)}">${esc(g.key)}</span><span class="vl">${valFn(g)}</span></li>`).join('') : '<li class="text-muted">No data</li>';

    const cust = KE.rank(KE.sortBy(S.g.cust, 'sales'));
    const active = cust.filter((x) => x.sales > 0);
    const top10 = active.slice(0, 10).reduce((a, b) => a + b.sales, 0);
    $('#custStats').innerHTML = mini('Active Customers', FMT.num(active.length), `of ${FMT.num(cust.length)} in selection`) + mini('Sales Per Customer', FMT.compact(active.length ? k.sales / active.length : 0), 'average') +
      mini('Top-10 Concentration', FMT.pct(k.sales ? (top10 / k.sales) * 100 : 0), 'share of total sales') + mini('Average Invoice Value', FMT.compact(k.avgInvoice), 'all customers');
    $('#custTop').innerHTML = list(active.slice(0, 5), (g) => `${FMT.compact(g.sales)} <small>${FMT.pct(g.contrib)}</small>`);
    const bottom = active.slice(-5).reverse().map((g) => g);
    $('#custBottom').innerHTML = list(bottom, (g) => `${FMT.compact(g.sales)} <small>${FMT.pct(g.contrib)}</small>`);

    const prod = KE.rank(KE.sortBy(S.g.mat, 'sales'));
    const pa = prod.filter((x) => x.sales > 0);
    const ptop10 = pa.slice(0, 10).reduce((a, b) => a + b.sales, 0);
    $('#prodStats').innerHTML = mini('Active SKUs', FMT.num(pa.length), `of ${FMT.num(prod.length)} in selection`) + mini('Units Sold', FMT.compact(k.qty), 'net quantity') +
      mini('Top-10 SKU Share', FMT.pct(k.sales ? (ptop10 / k.sales) * 100 : 0), 'of total sales') + mini('Avg Sales / SKU', FMT.compact(pa.length ? k.sales / pa.length : 0), 'average');
    $('#prodTop').innerHTML = list(pa.slice(0, 5), (g) => `${FMT.compact(g.sales)} <small>${FMT.num(g.qty)} u</small>`);
    $('#prodBottom').innerHTML = list(pa.slice(-5).reverse(), (g) => `${FMT.compact(g.sales)} <small>${FMT.num(g.qty)} u</small>`);
  }

  /* ======================================================================
   * Header info + validation
   * ==================================================================== */
  function renderFileInfo() {
    const m = S.meta;
    $('#fileInfo').innerHTML = `<i class="bi bi-file-earmark-excel-fill"></i> <b title="${esc(m.fileName)}">${esc(FMT.short(m.fileName, 38))}</b>
      <span class="sep">·</span> ${FMT.num(m.cleanRows)} clean rows <span class="sep">·</span> ${m.minDt ? DP.isoDate(m.minDt) + ' → ' + DP.isoDate(m.maxDt) : 'no dates'}`;
  }

  function renderValidation() {
    const w = S.warnings;
    const issues = w.filter((x) => x.level !== 'info');
    const b = $('#validationBanner');
    b.classList.toggle('d-none', !w.length);
    b.className = 'val-banner ' + (w.some((x) => x.level === 'error') ? 'err' : issues.length ? 'warn' : 'ok') + (w.length ? '' : ' d-none');
    $('#valCount').innerHTML = issues.length ? `<b>${issues.length}</b> data-quality warning(s)` : 'Data cleaned successfully';
    $('#valSummary').textContent = `${FMT.num(S.meta.sourceRows)} source rows → ${FMT.num(S.meta.cleanRows)} clean rows · target layout: ${S.meta.targetMode === 'attached' ? 'attached to invoices (counted once)' : 'separate target rows'}`;
    const dt = jQuery('#tblValidation');
    if (jQuery.fn.DataTable.isDataTable(dt)) dt.DataTable().destroy();
    dt.DataTable({
      data: w.map((x) => [x.level, x.msg, x.count]), pageLength: 10, autoWidth: false, order: [[0, 'asc']],
      columns: [
        { title: 'Level', width: '90px', render: (d, t) => (t === 'display' ? `<span class="badge lvl-${d}">${d}</span>` : d) },
        { title: 'Message' }, { title: 'Count', className: 'text-end', width: '80px' }
      ]
    });
    if (issues.length && !S.viewOnly) UI.toast('warning', `${issues.length} data-quality warning(s) found. Click <b>View details</b> in the banner.`, 6000);
  }

  /* ======================================================================
   * Event wiring
   * ==================================================================== */
  function bindUI() {
    // theme
    let saved = 'dark'; try { saved = localStorage.getItem('sd-theme') || 'dark'; } catch (e) { /* ignore */ }
    UI.theme(saved);
    $('#btnTheme').onclick = () => { UI.theme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'); if (S.loaded) { CH.renderAll(S); } };
    $('#btnRefresh').onclick = () => { if (!S.loaded) return; UI.loading(true, 'Refreshing…'); setTimeout(() => { FE.refreshOptions(); refresh(); UI.loading(false); UI.toast('info', 'Dashboard refreshed.', 1800); }, 30); };
    $('#btnReset').onclick = () => { if (!S.loaded) return; FE.reset(); UI.toast('info', 'All filters reset.', 1800); };
    $('#btnFullscreen').onclick = () => EX.fullscreen();
    $('#btnPrint').onclick = () => EX.print();
    const wrap = (fn, msg) => async () => { if (!S.loaded) return UI.toast('warning', 'Load a file first.'); UI.loading(true, msg); try { await fn(); UI.toast('success', 'Export complete.', 2500); } catch (e) { console.error(e); UI.toast('error', 'Export failed: ' + esc(e.message)); } finally { UI.loading(false); } };
    $('#expPdf').onclick = wrap(() => EX.pdf(), 'Rendering PDF…');
    $('#expPng').onclick = wrap(() => EX.png(), 'Rendering PNG…');
    $('#expXlsx').onclick = wrap(() => EX.excel(S), 'Building Excel summary…');
    $('#btnShare').onclick = () => {
      if (!S.loaded) return UI.toast('warning', 'Load a file first.');
      try { const kb = EX.shareData(S); $('#shareSize').textContent = FMT.num(kb) + ' KB'; new bootstrap.Modal($('#shareModal')).show(); }
      catch (e) { console.error(e); UI.toast('error', 'Could not create share data: ' + esc(e.message)); }
    };
    $('#btnValDetails').onclick = () => new bootstrap.Modal($('#valModal')).show();

    // rank toggle (exec chart + league table)
    $$('[data-rank]').forEach((b) => (b.onclick = () => { S.rankBy = b.dataset.rank; $$('[data-rank]').forEach((x) => x.classList.toggle('active', x.dataset.rank === S.rankBy)); if (S.loaded) { CH.renderAll(S); renderGrids(); } }));
    $$('[data-prod]').forEach((b) => (b.onclick = () => { S.prodMode = b.dataset.prod; $$('[data-prod]').forEach((x) => x.classList.toggle('active', x.dataset.prod === S.prodMode)); if (S.loaded) CH.renderAll(S); }));

    // grid search + export
    [['qLeague', 'gridLeague'], ['qCust', 'gridCust'], ['qProd', 'gridProd'], ['qRaw', 'gridRaw']].forEach(([q, g]) => { $('#' + q).addEventListener('input', (e) => grids[g] && grids[g].setGridOption('quickFilterText', e.target.value)); });
    const names = { gridLeague: 'Executive_League', gridCust: 'Customers', gridProd: 'Products', gridRaw: 'Detail' };
    $$('[data-grid]').forEach((b) => (b.onclick = () => {
      const id = b.dataset.grid, api = grids[id]; if (!api) return UI.toast('warning', 'Load a file first.');
      try { if (b.dataset.fmt === 'csv') api.exportDataAsCsv({ fileName: names[id] + '.csv' }); else EX.gridToExcel(api, names[id]); } catch (e) { UI.toast('error', 'Export failed: ' + esc(e.message)); }
    }));

    let rt; window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => CH.resizeAll(), 200); });
    window.addEventListener('error', (e) => { console.error(e.error || e.message); });
    window.addEventListener('unhandledrejection', (e) => { console.error(e.reason); UI.toast('error', 'Unexpected error: ' + esc((e.reason && e.reason.message) || e.reason)); });
    document.addEventListener('fullscreenchange', () => { $('#btnFullscreen i').className = 'bi ' + (document.fullscreenElement ? 'bi-fullscreen-exit' : 'bi-arrows-fullscreen'); setTimeout(() => CH.resizeAll(), 250); });

    // nav highlighting
    const links = $$('.navpills a');
    const obs = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) links.forEach((l) => l.classList.toggle('active', l.getAttribute('href') === '#' + e.target.id)); }), { rootMargin: '-30% 0px -60% 0px' });
    $$('section[id]').forEach((s) => obs.observe(s));

    FE.onChange(() => refresh());
  }

  function boot() {
    const missing = [];
    if (typeof bootstrap === 'undefined') missing.push('Bootstrap');
    if (typeof Chart === 'undefined') missing.push('Chart.js');
    if (typeof Plotly === 'undefined') missing.push('Plotly');
    if (typeof XLSX === 'undefined') missing.push('SheetJS');
    if (typeof agGrid === 'undefined') missing.push('AG Grid');
    if (typeof jQuery === 'undefined' || !jQuery.fn.DataTable) missing.push('DataTables');
    if (missing.length) {
      document.getElementById('libError').classList.remove('d-none');
      document.getElementById('libError').innerHTML = `<i class="bi bi-wifi-off me-2"></i>Could not load: <b>${missing.join(', ')}</b>. The dashboard loads its libraries from a CDN - check your internet connection and reload.`;
    }
    if (window.bootstrap) {
      bindUI(); bindUpload();
      // View-only mode: a share-data.js file next to index.html embeds the dataset and removes every upload control.
      if (window.SD_EMBEDDED) {
        S.viewOnly = true; document.body.classList.add('view-only');
        try { load(DP.fromEmbedded(window.SD_EMBEDDED)); const b = new Date(window.SD_EMBEDDED.builtAt); $('#ctxLabel').textContent += ' · published ' + b.toLocaleDateString('en-GB'); }
        catch (e) { console.error(e); document.getElementById('libError').classList.remove('d-none'); document.getElementById('libError').textContent = 'Could not open the shared data: ' + e.message; }
      }
    }
  }
  document.addEventListener('DOMContentLoaded', boot);
})();
