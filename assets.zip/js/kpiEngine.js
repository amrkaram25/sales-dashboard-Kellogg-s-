/**
 * kpiEngine.js
 * ----------------------------------------------------------------------------
 * All business calculations: KPIs, grouping, ranking, forecast, insights.
 *
 * Conventions
 *  - Achievement / contribution values are PERCENT numbers (95.3 = 95.3%).
 *  - Gap = Target - Sales (positive = shortfall, negative = surplus).
 *  - Time basis ("ctx"): reporting month = month of the latest invoice date in
 *    the filtered data. Elapsed days = day-of-month of that date.
 *  - Target rows carry no date / material, so they are never date-filtered.
 */
(function (global) {
  'use strict';
  const DAY = 86400000;

  /* ---------------- Status / conditional formatting ---------------- */
  const STATUS = {
    green:  { key: 'green',  label: 'Achieved',    color: '#10b981' },
    yellow: { key: 'yellow', label: 'Near Target', color: '#facc15' },
    orange: { key: 'orange', label: 'At Risk',     color: '#fb923c' },
    red:    { key: 'red',    label: 'Critical',    color: '#ef4444' },
    gray:   { key: 'gray',   label: 'No Target',   color: '#94a3b8' }
  };
  /** 100%+ green, 90-99.99 yellow, 75-89.99 orange, <75 red */
  function status(ach) {
    if (ach == null || !isFinite(ach)) return STATUS.gray;
    if (ach >= 100) return STATUS.green;
    if (ach >= 90) return STATUS.yellow;
    if (ach >= 75) return STATUS.orange;
    return STATUS.red;
  }
  const FORECAST_LABEL = { green: 'On Track', yellow: 'Near Target', orange: 'At Risk', red: 'Critical', gray: 'No Target' };

  /* ---------------- Time context ---------------- */
  function timeContext(rows, fallbackMaxDt) {
    let max = null;
    for (let i = 0; i < rows.length; i++) { const r = rows[i]; if (!r.isTarget && r.dt != null && (max == null || r.dt > max)) max = r.dt; }
    if (max == null) max = fallbackMaxDt;
    if (max == null) return { asOf: null, monthStart: null, monthEnd: null, elapsed: 0, totalDays: 0, remaining: 0, label: '-' };
    const d = new Date(max);
    const y = d.getUTCFullYear(), m = d.getUTCMonth();
    const monthStart = Date.UTC(y, m, 1);
    const totalDays = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
    const elapsed = d.getUTCDate();
    return {
      asOf: max, monthStart, monthEnd: Date.UTC(y, m, totalDays), elapsed, totalDays,
      remaining: Math.max(0, totalDays - elapsed),
      label: d.toLocaleDateString('en-GB', { month: 'long', year: 'numeric', timeZone: 'UTC' })
    };
  }

  /* ---------------- Grouping ---------------- */
  /**
   * Aggregate rows by a field. Returns array of group objects (unsorted).
   */
  function group(rows, field, ctx, totalSales) {
    const map = new Map();
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      const k = r[field];
      if (k == null) continue;
      let g = map.get(k);
      if (!g) {
        g = { key: k, sales: 0, mtd: 0, target: 0, qty: 0, inv: new Set(), so: new Set(), prods: new Set(), custs: new Set(), lines: 0, code: null, div: r.div, sup: r.sup, exec: r.exec };
        map.set(k, g);
      }
      if (r.isTarget) { g.target += r.target; continue; }
      g.sales += r.gsv; g.qty += r.qty; g.lines++;
      if (ctx.monthStart != null && r.dt != null && r.dt >= ctx.monthStart && r.dt <= ctx.monthEnd) g.mtd += r.gsv;
      if (r.inv) g.inv.add(r.inv);
      if (r.so) g.so.add(r.so);
      if (r.mat) g.prods.add(r.mat);
      g.custs.add(r.cust);
      if (!g.code && r.matCode) g.code = r.matCode;
    }
    const out = [];
    map.forEach((g) => {
      g.invoices = g.inv.size; g.orders = g.so.size; g.customers = g.custs.size; g.products = g.prods.size;
      g.ach = g.target > 0 ? (g.sales / g.target) * 100 : null;
      g.gap = g.target - g.sales;
      g.forecast = ctx.elapsed > 0 ? (g.mtd / ctx.elapsed) * ctx.totalDays : g.mtd;
      g.fAch = g.target > 0 ? (g.forecast / g.target) * 100 : null;
      g.status = status(g.ach);
      g.fStatus = status(g.fAch);
      g.contrib = totalSales ? (g.sales / totalSales) * 100 : 0;
      g.avgInv = g.invoices ? g.sales / g.invoices : 0;
      g.reqDaily = ctx.remaining > 0 ? Math.max(0, g.target - g.sales) / ctx.remaining : Math.max(0, g.target - g.sales);
      delete g.inv; delete g.so; delete g.prods; delete g.custs;
      out.push(g);
    });
    return out;
  }

  /** Sort helpers. Groups without a target always sink to the bottom when sorting by ach. */
  function sortBy(arr, by) {
    const a = arr.slice();
    if (by === 'ach') a.sort((x, y) => (y.ach == null) - (x.ach == null) || (y.ach || 0) - (x.ach || 0) || y.sales - x.sales);
    else if (by === 'qty') a.sort((x, y) => y.qty - x.qty);
    else a.sort((x, y) => y.sales - x.sales);
    return a;
  }
  function rank(arr) { arr.forEach((g, i) => { g.rank = i + 1; }); return arr; }

  /* ---------------- Daily series ---------------- */
  function dailySeries(rows, ctx) {
    const byDay = new Map();
    let min = null, max = null;
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      if (r.isTarget || r.dt == null) continue;
      byDay.set(r.dt, (byDay.get(r.dt) || 0) + r.gsv);
      if (min == null || r.dt < min) min = r.dt;
      if (max == null || r.dt > max) max = r.dt;
    }
    if (min == null) return { labels: [], dts: [], gsv: [], ma: [], forecast: [], runRate: 0 };
    const start = Math.min(min, ctx.monthStart != null ? ctx.monthStart : min);
    const end = Math.max(max, ctx.monthEnd != null ? ctx.monthEnd : max);
    const dts = [], gsv = [];
    for (let t = start; t <= end; t += DAY) { dts.push(t); gsv.push(t <= max ? (byDay.get(t) || 0) : null); }
    // 7-day trailing moving average (actual days only)
    const ma = gsv.map((v, i) => {
      if (v == null) return null;
      let s = 0, c = 0;
      for (let j = Math.max(0, i - 6); j <= i; j++) { if (gsv[j] != null) { s += gsv[j]; c++; } }
      return c ? s / c : null;
    });
    // Forecast trend: from last actual day, project the run-rate until month end
    const runRate = ctx.elapsed > 0 ? sum(rows, (r) => (!r.isTarget && r.dt >= ctx.monthStart && r.dt <= ctx.monthEnd ? r.gsv : 0)) / ctx.elapsed : 0;
    const lastIdx = dts.indexOf(max);
    const forecast = dts.map((t, i) => (i === lastIdx ? gsv[i] : i > lastIdx && t <= ctx.monthEnd ? runRate : null));
    return { labels: dts.map((t) => new Date(t).toISOString().slice(0, 10)), dts, gsv, ma, forecast, runRate, lastIdx };
  }

  function sum(rows, fn) { let s = 0; for (let i = 0; i < rows.length; i++) s += fn(rows[i]); return s; }
  function stdev(a) { if (a.length < 2) return 0; const m = a.reduce((x, y) => x + y, 0) / a.length; return Math.sqrt(a.reduce((x, y) => x + (y - m) * (y - m), 0) / a.length); }

  /* ---------------- Main KPI computation ---------------- */
  function compute(rows, meta) {
    const ctx = timeContext(rows, meta && meta.maxDt);
    const inv = new Set(), so = new Set(), custS = new Map(), prodS = new Map();
    let sales = 0, target = 0, mtd = 0, qty = 0;
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      if (r.isTarget) { target += r.target; continue; }
      sales += r.gsv; qty += r.qty;
      if (ctx.monthStart != null && r.dt != null && r.dt >= ctx.monthStart && r.dt <= ctx.monthEnd) mtd += r.gsv;
      if (r.inv) inv.add(r.inv);
      if (r.so) so.add(r.so);
      custS.set(r.cust, (custS.get(r.cust) || 0) + r.gsv);
      if (r.mat) prodS.set(r.mat, (prodS.get(r.mat) || 0) + r.gsv);
    }
    let activeCust = 0, activeProd = 0;
    custS.forEach((v) => { if (v > 0) activeCust++; });
    prodS.forEach((v) => { if (v > 0) activeProd++; });

    const ach = target > 0 ? (sales / target) * 100 : null;
    const remaining = target - sales;
    const avgDaily = ctx.elapsed > 0 ? mtd / ctx.elapsed : 0;
    const forecast = ctx.elapsed > 0 ? (mtd / ctx.elapsed) * ctx.totalDays : mtd;
    const fAch = target > 0 ? (forecast / target) * 100 : null;
    const reqDaily = ctx.remaining > 0 ? Math.max(0, remaining) / ctx.remaining : Math.max(0, remaining);
    const daily = dailySeries(rows, ctx);

    // last-7-days average for the run-rate sub text
    const actual = daily.gsv.filter((v) => v != null);
    const last7 = actual.slice(-7);
    const last7Avg = last7.length ? last7.reduce((a, b) => a + b, 0) / last7.length : 0;

    // Forecast confidence: coverage of the month (60%) + stability of daily sales (40%)
    const monthDays = actual.slice(-Math.max(1, ctx.elapsed));
    const mean = monthDays.length ? monthDays.reduce((a, b) => a + b, 0) / monthDays.length : 0;
    const cv = mean > 0 ? stdev(monthDays) / mean : 1;
    const coverage = ctx.totalDays ? Math.min(1, (ctx.elapsed / ctx.totalDays) / 0.6) : 0;
    const confidence = Math.round(100 * (0.6 * coverage + 0.4 * Math.max(0, 1 - Math.min(cv, 1.5) / 1.5)));
    const confLabel = confidence >= 70 ? 'High' : confidence >= 45 ? 'Medium' : 'Low';

    return {
      ctx, daily,
      sales, target, mtd, qty, ach, remaining, forecast, fAch,
      invoices: inv.size, orders: so.size, activeCust, activeProd,
      avgInvoice: inv.size ? sales / inv.size : 0,
      avgDaily, reqDaily, runRate: avgDaily, last7Avg,
      status: status(ach), fStatus: status(fAch),
      forecastGap: target - forecast,
      confidence, confLabel
    };
  }

  /* ---------------- Executive insights ---------------- */
  function insights(k, g) {
    const withT = (a) => a.filter((x) => x.target > 0 && x.ach != null);
    const best = (a, f, dir) => a.length ? a.slice().sort((x, y) => dir * (f(y) - f(x)))[0] : null;
    const exec = withT(g.exec), sup = withT(g.sup), divs = withT(g.div);
    const bestExec = best(exec, (x) => x.ach, 1);
    const worst = best(exec, (x) => x.ach, -1);
    const bestSup = best(sup, (x) => x.ach, 1);
    const bestDiv = divs.length ? best(divs, (x) => x.ach, 1) : best(g.div, (x) => x.sales, 1);
    const bestCust = best(g.cust, (x) => x.sales, 1);
    const bestProd = best(g.mat, (x) => x.sales, 1);
    const topContrib = best(g.exec, (x) => x.contrib, 1);
    const gapExec = best(g.exec.filter((x) => x.target > 0), (x) => x.gap, 1);
    return {
      bestExec, bestSup, bestDiv, bestCust, bestProd, topContrib, gapExec, worst,
      highestAch: bestExec
    };
  }

  /** Plain-English narrative lines for the summary panel. */
  function narrative(k, ins, fmt) {
    const L = [];
    if (k.ach == null) { L.push('No target is loaded for the current selection, so achievement cannot be calculated.'); return L; }
    L.push(`Sales stand at <b>${fmt.pct(k.ach)}</b> of target with <b>${k.ctx.remaining}</b> day(s) left in ${k.ctx.label}.`);
    L.push(`At the current run-rate the month is forecast to close at <b>${fmt.compact(k.forecast)}</b> (<b>${fmt.pct(k.fAch)}</b>), a ${k.forecastGap > 0 ? 'shortfall' : 'surplus'} of <b>${fmt.compact(Math.abs(k.forecastGap))}</b>.`);
    if (k.remaining > 0 && k.ctx.remaining > 0) {
      const mult = k.runRate > 0 ? k.reqDaily / k.runRate : null;
      L.push(`Required daily sales of <b>${fmt.compact(k.reqDaily)}</b> vs current <b>${fmt.compact(k.runRate)}</b>${mult ? ` - a <b>${mult.toFixed(1)}x</b> step-up is needed` : ''}.`);
    } else if (k.remaining <= 0) L.push('The monthly target has already been reached.');
    if (ins.worst && ins.bestExec && ins.worst.key !== ins.bestExec.key) L.push(`Spread between best (<b>${ins.bestExec.key}</b>, ${fmt.pct(ins.bestExec.ach)}) and weakest (<b>${ins.worst.key}</b>, ${fmt.pct(ins.worst.ach)}) executive is <b>${(ins.bestExec.ach - ins.worst.ach).toFixed(1)} pts</b>.`);
    return L;
  }

  global.KE = { STATUS, status, FORECAST_LABEL, timeContext, group, sortBy, rank, dailySeries, compute, insights, narrative, DAY };
})(window);
