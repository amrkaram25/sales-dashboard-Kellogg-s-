/**
 * charts.js
 * ----------------------------------------------------------------------------
 * Chart.js + Plotly.js rendering layer.
 *   Chart.js : Division combo, Daily trend, Exec / Supervisor / Manager ranking,
 *              Top customers, Top products, Donut, Forecast chart, Gauge
 *   Plotly   : Burn-up pace chart, Pareto 80/20
 * Every chart is theme aware and click-to-cross-filter where it makes sense.
 */
(function (global) {
  'use strict';

  /* ---------------- Number formatting (shared) ---------------- */
  const FMT = {
    num: (n) => (n == null || !isFinite(n) ? '-' : Math.round(n).toLocaleString('en-US')),
    compact(n) {
      if (n == null || !isFinite(n)) return '-';
      const a = Math.abs(n), s = n < 0 ? '-' : '';
      if (a >= 1e9) return s + (a / 1e9).toFixed(2) + 'B';
      if (a >= 1e6) return s + (a / 1e6).toFixed(a >= 1e7 ? 1 : 2) + 'M';
      if (a >= 1e3) return s + (a / 1e3).toFixed(a >= 1e5 ? 0 : 1) + 'K';
      return s + Math.round(a).toLocaleString('en-US');
    },
    pct: (v, d) => (v == null || !isFinite(v) ? 'N/A' : v.toFixed(d == null ? 1 : d) + '%'),
    short: (s, n) => (String(s).length > n ? String(s).slice(0, n - 1) + '…' : String(s)),
    day: (iso) => new Date(iso + 'T00:00:00Z').toLocaleDateString('en-GB', { day: '2-digit', month: 'short', timeZone: 'UTC' })
  };

  /* ---------------- Theme ---------------- */
  function theme() {
    const cs = getComputedStyle(document.documentElement);
    const v = (n) => cs.getPropertyValue(n).trim();
    return {
      text: v('--text'), muted: v('--muted'), grid: v('--grid'), surface: v('--card-solid'),
      sales: v('--c-sales'), target: v('--c-target'), accent: v('--c-accent'), forecast: v('--c-forecast'), ma: v('--c-ma'),
      dark: document.documentElement.getAttribute('data-theme') === 'dark'
    };
  }

  /* Colour-by-entity so filters never repaint surviving series */
  const CAT = ['#38bdf8', '#10b981', '#818cf8', '#f59e0b', '#f472b6', '#2dd4bf', '#a3e635', '#fb7185', '#94a3b8'];
  const catMap = new Map();
  function colorFor(name) { if (!catMap.has(name)) catMap.set(name, CAT[catMap.size % CAT.length]); return catMap.get(name); }

  const inst = {};
  function make(id, cfg) {
    if (inst[id]) { inst[id].destroy(); delete inst[id]; }
    const el = document.getElementById(id); if (!el) return null;
    inst[id] = new Chart(el.getContext('2d'), cfg);
    return inst[id];
  }
  function empty(id, on) {
    const el = document.getElementById(id); if (!el) return;
    const box = el.closest('.chart-box') || el.parentElement;
    let m = box.querySelector('.empty-msg');
    if (on) { if (!m) { m = document.createElement('div'); m.className = 'empty-msg'; m.textContent = 'No data for the current selection'; box.appendChild(m); } }
    else if (m) m.remove();
  }

  /* ---------------- Reusable plugins ---------------- */
  /** Draws a text label at the end of each horizontal bar */
  const EndLabels = {
    id: 'endLabels',
    afterDatasetsDraw(chart, args, opts) {
      if (!opts || !opts.fn) return;
      const { ctx } = chart; const t = theme();
      const metas = chart.data.datasets.map((_, i) => chart.getDatasetMeta(i)).filter((m) => !m.hidden);
      if (!metas.length) return;
      ctx.save(); ctx.font = '600 11px ' + Chart.defaults.font.family; ctx.textBaseline = 'middle'; ctx.fillStyle = t.text;
      metas[0].data.forEach((el, i) => {
        let x = 0; metas.forEach((m) => { if (m.data[i]) x = Math.max(x, chart.options.indexAxis === 'y' ? m.data[i].x : m.data[i].x); });
        const txt = opts.fn(i); if (!txt) return;
        ctx.textAlign = 'left'; ctx.fillText(txt, x + 6, el.y);
      });
      ctx.restore();
    }
  };

  const DonutCenter = {
    id: 'donutCenter',
    afterDraw(chart, args, opts) {
      if (!opts || !opts.title) return;
      const m = chart.getDatasetMeta(0); if (!m.data.length) return;
      const { x, y } = m.data[0]; const t = theme(); const c = chart.ctx;
      c.save(); c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillStyle = t.text; c.font = '700 20px ' + Chart.defaults.font.family; c.fillText(opts.title, x, y - 6);
      c.fillStyle = t.muted; c.font = '500 11px ' + Chart.defaults.font.family; c.fillText(opts.sub || '', x, y + 14);
      c.restore();
    }
  };

  const GaugeNeedle = {
    id: 'gaugeNeedle',
    afterDatasetsDraw(chart, args, o) {
      if (!o || o.value == null) return;
      const m = chart.getDatasetMeta(0).data[0]; if (!m) return; const t = theme(); const c = chart.ctx;
      const max = o.max;
      const ang = (v) => Math.PI + Math.PI * Math.min(Math.max(v, 0), max) / max;
      const cx = m.x, cy = m.y, R = m.outerRadius, r = m.innerRadius;
      // forecast marker (triangle on the outer rim)
      if (o.forecast != null) {
        c.save();
        c.translate(cx, cy); c.rotate(ang(o.forecast));
        c.fillStyle = t.forecast; c.beginPath(); c.moveTo(R + 2, 0); c.lineTo(R + 12, -6); c.lineTo(R + 12, 6); c.closePath(); c.fill();
        c.restore();
      }
      c.save();
      // needle
      const a = ang(o.value);
      c.translate(cx, cy); c.rotate(a);
      c.fillStyle = t.text; c.beginPath(); c.moveTo(0, -4); c.lineTo(R * 0.93, 0); c.lineTo(0, 4); c.closePath(); c.fill();
      c.beginPath(); c.arc(0, 0, 9, 0, Math.PI * 2); c.fill();
      c.fillStyle = t.surface; c.beginPath(); c.arc(0, 0, 3.5, 0, Math.PI * 2); c.fill();
      c.restore();
      // scale labels
      c.save(); c.fillStyle = t.muted; c.font = '500 10px ' + Chart.defaults.font.family; c.textAlign = 'center';
      [0, 50, 100, 150].forEach((v) => { const a2 = ang(v), rr = R + 16; c.fillText(v + '%', cx + Math.cos(a2) * rr, cy + Math.sin(a2) * rr + (v === 0 || v === max ? -2 : 0)); });
      c.restore();
    }
  };

  /* ---------------- Shared option builders ---------------- */
  function baseOptions(t) {
    return {
      responsive: true, maintainAspectRatio: false, animation: { duration: 450 },
      plugins: {
        legend: { labels: { color: t.text, usePointStyle: true, boxWidth: 8, boxHeight: 8, font: { size: 11 } } },
        tooltip: { backgroundColor: t.dark ? '#0b1b3a' : '#0f172a', titleColor: '#fff', bodyColor: '#e2e8f0', borderColor: 'rgba(148,163,184,.35)', borderWidth: 1, padding: 10, cornerRadius: 8, displayColors: true, boxPadding: 4 }
      }
    };
  }
  const axisStyle = (t, fmt) => ({ ticks: { color: t.muted, font: { size: 11 }, callback: fmt }, grid: { color: t.grid, drawBorder: false }, border: { display: false } });
  const catAxis = (t, maxLen) => ({ ticks: { color: t.text, font: { size: 11 }, callback(v) { return FMT.short(this.getLabelForValue(v), maxLen || 22); } }, grid: { display: false }, border: { display: false } });

  function hoverCursor(field) {
    return (e, els) => { e.native.target.style.cursor = field && els.length ? 'pointer' : 'default'; };
  }
  function clickFilter(field) {
    return (e, els, chart) => { if (field && els.length) FE.toggle(field, chart.data.labels[els[0].index]); };
  }

  /** Horizontal sales-vs-target chart with end labels (executives / supervisors / managers) */
  function hbarTargets(id, list, o) {
    const t = theme();
    empty(id, !list.length);
    if (!list.length) { if (inst[id]) { inst[id].destroy(); delete inst[id]; } return; }
    const n = list.length;
    const colors = list.map((g, i) => {
      if (o.highlight) { if (i < 3) return '#10b981'; if (n > 3 && i >= n - 3 && i >= 3) return '#ef4444'; return t.sales; }
      return g.status.color;
    });
    const active = o.field ? FE.state.sets[o.field] : null;
    const cfg = {
      type: 'bar',
      data: {
        labels: list.map((g) => g.key),
        datasets: [
          { label: 'Target', data: list.map((g) => g.target), backgroundColor: t.target, borderRadius: 4, barPercentage: 0.95, categoryPercentage: 0.9, grouped: false, order: 2 },
          { label: 'Sales', data: list.map((g) => g.sales), backgroundColor: colors.map((c, i) => (active && active.size && !active.has(list[i].key) ? c + '55' : c)), borderRadius: 4, barPercentage: 0.5, categoryPercentage: 0.9, grouped: false, order: 1 }
        ]
      },
      options: Object.assign(baseOptions(t), {
        indexAxis: 'y', layout: { padding: { right: 110 } },
        onClick: clickFilter(o.field), onHover: hoverCursor(o.field),
        scales: { x: Object.assign(axisStyle(t, (v) => FMT.compact(v)), { beginAtZero: true }), y: catAxis(t, o.maxLen || 24) }
      }),
      plugins: [EndLabels]
    };
    cfg.options.plugins.endLabels = { fn: (i) => (o.rankNo ? '#' + list[i].rank + '  ' : '') + FMT.pct(list[i].ach) };
    cfg.options.plugins.tooltip.callbacks = {
      title: (items) => list[items[0].dataIndex].key,
      label: (c) => ` ${c.dataset.label}: ${FMT.num(c.parsed.x)}`,
      afterBody: (items) => { const g = list[items[0].dataIndex]; return ['', `Achievement: ${FMT.pct(g.ach)}`, `Gap to target: ${FMT.num(g.gap)}`, `Contribution: ${FMT.pct(g.contrib)}`, `Forecast: ${FMT.num(g.forecast)} (${FMT.pct(g.fAch)})`]; }
    };
    make(id, cfg);
  }

  /* ---------------- Individual charts ---------------- */
  function divisionCombo(g, t) {
    const list = g.div.slice().sort((a, b) => b.sales - a.sales);
    empty('chDivision', !list.length);
    if (!list.length) return;
    const cfg = {
      data: {
        labels: list.map((x) => x.key),
        datasets: [
          { type: 'bar', label: 'Actual Sales', data: list.map((x) => x.sales), backgroundColor: t.sales, borderRadius: 5, yAxisID: 'y', order: 2, maxBarThickness: 46 },
          { type: 'bar', label: 'Target', data: list.map((x) => x.target), backgroundColor: t.target, borderRadius: 5, yAxisID: 'y', order: 2, maxBarThickness: 46 },
          { type: 'line', label: 'Achievement %', data: list.map((x) => x.ach), yAxisID: 'y1', borderColor: t.accent, backgroundColor: t.accent, pointBackgroundColor: list.map((x) => x.status.color), pointBorderColor: t.surface, pointBorderWidth: 2, pointRadius: 6, pointHoverRadius: 8, borderWidth: 2.5, tension: 0.25, order: 1 }
        ]
      },
      options: Object.assign(baseOptions(t), {
        interaction: { mode: 'index', intersect: false },
        onClick: clickFilter('div'), onHover: hoverCursor('div'),
        scales: {
          x: catAxis(t, 18),
          y: Object.assign(axisStyle(t, (v) => FMT.compact(v)), { beginAtZero: true, title: { display: true, text: 'GSV', color: t.muted } }),
          y1: Object.assign(axisStyle(t, (v) => v + '%'), { position: 'right', beginAtZero: true, grid: { drawOnChartArea: false }, title: { display: true, text: 'Achievement %', color: t.muted } })
        }
      })
    };
    cfg.options.plugins.tooltip.callbacks = { label: (c) => ` ${c.dataset.label}: ${c.dataset.yAxisID === 'y1' ? FMT.pct(c.parsed.y) : FMT.num(c.parsed.y)}` };
    make('chDivision', cfg);
  }

  function dailyTrend(k, t) {
    const d = k.daily;
    empty('chDaily', !d.labels.length);
    if (!d.labels.length) { if (inst.chDaily) { inst.chDaily.destroy(); delete inst.chDaily; } return; }
    const cfg = {
      type: 'line',
      data: {
        labels: d.labels.map(FMT.day),
        datasets: [
          { label: 'Daily GSV', data: d.gsv, borderColor: t.sales, backgroundColor: t.sales + '26', fill: true, tension: 0.3, borderWidth: 2, pointRadius: 2.5, pointHoverRadius: 6, spanGaps: false },
          { label: '7-Day Moving Avg', data: d.ma, borderColor: t.accent, borderWidth: 2.5, pointRadius: 0, tension: 0.35, spanGaps: false },
          { label: 'Forecast Trend (run-rate)', data: d.forecast, borderColor: t.forecast, borderDash: [6, 5], borderWidth: 2, pointRadius: 0, spanGaps: true }
        ]
      },
      options: Object.assign(baseOptions(t), {
        interaction: { mode: 'index', intersect: false },
        scales: { x: Object.assign(axisStyle(t), { grid: { display: false }, ticks: { color: t.muted, maxRotation: 0, autoSkip: true, maxTicksLimit: 16, font: { size: 11 } } }), y: Object.assign(axisStyle(t, (v) => FMT.compact(v)), { beginAtZero: true }) }
      })
    };
    cfg.options.plugins.tooltip.callbacks = { title: (it) => d.labels[it[0].dataIndex], label: (c) => (c.parsed.y == null ? null : ` ${c.dataset.label}: ${FMT.num(c.parsed.y)}`) };
    make('chDaily', cfg);
  }

  function burnUp(k, t) {
    const el = document.getElementById('plotBurn'); if (!el) return;
    const c = k.ctx, d = k.daily;
    if (el.querySelector('.empty-msg')) { Plotly.purge(el); el.innerHTML = ''; }
    if (!c.asOf || !d.dts.length) { Plotly.purge(el); el.innerHTML = '<div class="empty-msg">No data for the current selection</div>'; return; }
    const days = [0], cum = [0]; let run = 0;
    d.dts.forEach((ts, i) => { if (ts >= c.monthStart && ts <= c.asOf) { run += d.gsv[i] || 0; days.push(new Date(ts).getUTCDate()); cum.push(run); } });
    const T = k.target, N = c.totalDays;
    const x0 = Array.from({ length: N + 1 }, (_, i) => i);
    const traces = [
      { x: [0, N], y: [T, T], name: 'Target', mode: 'lines', line: { color: t.muted, width: 2, dash: 'dash' }, hovertemplate: 'Target: %{y:,.0f}<extra></extra>' },
      { x: x0, y: x0.map((i) => (T * i) / N), name: 'Required Pace', mode: 'lines', line: { color: t.sales, width: 2, dash: 'dot' }, hovertemplate: 'Day %{x} pace: %{y:,.0f}<extra></extra>' },
      { x: days, y: cum, name: 'Current Achievement', mode: 'lines+markers', fill: 'tozeroy', fillcolor: t.accent + '26', line: { color: t.accent, width: 3 }, marker: { size: 5 }, hovertemplate: 'Day %{x} cumulative: %{y:,.0f}<extra></extra>' },
      { x: [c.elapsed, N], y: [run, k.forecast], name: 'Forecast Achievement', mode: 'lines', line: { color: t.forecast, width: 2.5, dash: 'dash' }, hovertemplate: 'Forecast day %{x}: %{y:,.0f}<extra></extra>' }
    ];
    if (T > 0 && c.remaining > 0) traces.push({ x: [c.elapsed, N], y: [run, T], name: 'Required From Today', mode: 'lines', line: { color: '#a78bfa', width: 1.5, dash: 'longdash' }, hovertemplate: 'Required day %{x}: %{y:,.0f}<extra></extra>' });
    const layout = plotLayout(t, { xaxis: { title: { text: 'Day of month (' + c.label + ')' }, range: [0, N], dtick: 2 }, yaxis: { tickformat: ',.2s', rangemode: 'tozero' } });
    layout.annotations = [{ x: c.elapsed, y: run, text: k.ach == null ? 'Now' : 'Now: ' + FMT.pct(k.ach), showarrow: true, arrowcolor: t.accent, ax: -40, ay: -40, font: { color: t.text, size: 11 }, bgcolor: t.surface, bordercolor: t.accent }];
    Plotly.react(el, traces, layout, { responsive: true, displayModeBar: false });
  }

  function plotLayout(t, extra) {
    const base = {
      paper_bgcolor: 'rgba(0,0,0,0)', plot_bgcolor: 'rgba(0,0,0,0)', font: { color: t.text, family: Chart.defaults.font.family, size: 11 },
      margin: { l: 56, r: 24, t: 10, b: 48 }, hovermode: 'x unified', hoverlabel: { bgcolor: '#0f172a', font: { color: '#fff' } },
      legend: { orientation: 'h', y: -0.22, font: { color: t.text } },
      xaxis: { gridcolor: t.grid, zeroline: false, linecolor: t.grid, tickfont: { color: t.muted } },
      yaxis: { gridcolor: t.grid, zeroline: false, tickfont: { color: t.muted } }
    };
    Object.keys(extra || {}).forEach((k) => { base[k] = Object.assign({}, base[k], extra[k]); });
    return base;
  }

  function donut(g, k, t) {
    const list = g.div.filter((x) => x.sales > 0).sort((a, b) => b.sales - a.sales);
    empty('chDonut', !list.length);
    if (!list.length) { if (inst.chDonut) { inst.chDonut.destroy(); delete inst.chDonut; } return; }
    const act = FE.state.sets.div;
    const cfg = {
      type: 'doughnut',
      data: { labels: list.map((x) => x.key), datasets: [{ data: list.map((x) => x.sales), backgroundColor: list.map((x) => colorFor(x.key) + (act.size && !act.has(x.key) ? '55' : '')), borderColor: t.surface, borderWidth: 3, hoverOffset: 8 }] },
      options: Object.assign(baseOptions(t), { cutout: '66%', onClick: clickFilter('div'), onHover: hoverCursor('div'), plugins: Object.assign(baseOptions(t).plugins, { legend: { position: 'right', labels: { color: t.text, usePointStyle: true, boxWidth: 8, font: { size: 12 }, generateLabels(ch) { const ds = ch.data.datasets[0]; const tot = ds.data.reduce((a, b) => a + b, 0); return ch.data.labels.map((l, i) => ({ text: `${l}  ${(ds.data[i] / tot * 100).toFixed(1)}%`, fillStyle: colorFor(l), strokeStyle: colorFor(l), fontColor: t.text, pointStyle: 'circle', index: i })); } } }, donutCenter: { title: FMT.compact(k.sales), sub: 'Total GSV' } }) }),
      plugins: [DonutCenter]
    };
    cfg.options.plugins.tooltip.callbacks = { label: (c) => { const tot = c.dataset.data.reduce((a, b) => a + b, 0); return ` ${c.label}: ${FMT.num(c.parsed)} (${(c.parsed / tot * 100).toFixed(1)}%)`; } };
    make('chDonut', cfg);
  }

  function pareto(g, t) {
    const el = document.getElementById('plotPareto'); if (!el) return;
    if (el.querySelector('.empty-msg')) { Plotly.purge(el); el.innerHTML = ''; }
    const list = g.cust.filter((x) => x.sales > 0).sort((a, b) => b.sales - a.sales);
    if (!list.length) { Plotly.purge(el); el.innerHTML = '<div class="empty-msg">No data for the current selection</div>'; return; }
    const tot = list.reduce((a, b) => a + b.sales, 0); let run = 0;
    const cumPct = list.map((x) => (run += x.sales, (run / tot) * 100));
    const n80 = cumPct.findIndex((v) => v >= 80) + 1;
    const names = list.map((x) => x.key);
    const traces = [
      { type: 'bar', x: names, y: list.map((x) => x.sales), name: 'Customer Sales', marker: { color: list.map((_, i) => (i < n80 ? t.sales : t.target)) }, customdata: list.map((x) => [x.contrib, x.invoices]), hovertemplate: '<b>%{x}</b><br>Sales: %{y:,.0f}<br>Share: %{customdata[0]:.1f}%<br>Invoices: %{customdata[1]}<extra></extra>' },
      { type: 'scatter', mode: 'lines+markers', x: names, y: cumPct, yaxis: 'y2', name: 'Cumulative %', line: { color: t.accent, width: 2.5 }, marker: { size: 4 }, hovertemplate: 'Cumulative: %{y:.1f}%<extra></extra>' }
    ];
    const layout = plotLayout(t, { xaxis: { showticklabels: list.length <= 25, tickangle: -40, automargin: true }, yaxis: { tickformat: ',.2s', title: { text: 'GSV' } } });
    layout.hovermode = 'closest';
    layout.margin.b = list.length <= 25 ? 110 : 56;
    layout.yaxis2 = { overlaying: 'y', side: 'right', range: [0, 105], ticksuffix: '%', showgrid: false, tickfont: { color: t.muted } };
    layout.shapes = [{ type: 'line', xref: 'paper', x0: 0, x1: 1, yref: 'y2', y0: 80, y1: 80, line: { color: t.forecast, width: 1.5, dash: 'dash' } }];
    layout.annotations = [{ xref: 'paper', x: 0.99, xanchor: 'right', yref: 'y2', y: 84, showarrow: false, font: { color: t.forecast, size: 11 }, text: `<b>${n80}</b> of ${list.length} customers (${(n80 / list.length * 100).toFixed(0)}%) = 80% of sales` }];
    layout.legend.y = list.length <= 25 ? -0.5 : -0.2;
    Plotly.react(el, traces, layout, { responsive: true, displayModeBar: false }).then(() => {
      el.removeAllListeners && el.removeAllListeners('plotly_click');
      el.on('plotly_click', (ev) => { const p = ev.points[0]; if (p && p.data.type === 'bar') FE.toggle('cust', p.x); });
    });
  }

  function forecastChart(g, k, t) {
    const list = g.div.slice().sort((a, b) => b.sales - a.sales);
    empty('chForecast', !list.length);
    if (!list.length) { if (inst.chForecast) { inst.chForecast.destroy(); delete inst.chForecast; } return; }
    const cfg = {
      data: {
        labels: list.map((x) => x.key),
        datasets: [
          { type: 'bar', label: 'Actual Sales', data: list.map((x) => x.sales), backgroundColor: t.sales, borderRadius: 4, yAxisID: 'y', maxBarThickness: 36 },
          { type: 'bar', label: 'Forecast Sales', data: list.map((x) => x.forecast), backgroundColor: t.forecast + 'cc', borderRadius: 4, yAxisID: 'y', maxBarThickness: 36 },
          { type: 'bar', label: 'Target', data: list.map((x) => x.target), backgroundColor: t.target, borderRadius: 4, yAxisID: 'y', maxBarThickness: 36 },
          { type: 'line', label: 'Forecast Achievement %', data: list.map((x) => x.fAch), yAxisID: 'y1', borderColor: t.accent, backgroundColor: t.accent, pointBackgroundColor: list.map((x) => x.fStatus.color), pointBorderColor: t.surface, pointBorderWidth: 2, pointRadius: 6, borderWidth: 2.5, tension: 0.2 }
        ]
      },
      options: Object.assign(baseOptions(t), {
        interaction: { mode: 'index', intersect: false }, onClick: clickFilter('div'), onHover: hoverCursor('div'),
        scales: { x: catAxis(t, 18), y: Object.assign(axisStyle(t, (v) => FMT.compact(v)), { beginAtZero: true }), y1: Object.assign(axisStyle(t, (v) => v + '%'), { position: 'right', beginAtZero: true, grid: { drawOnChartArea: false } }) }
      })
    };
    cfg.options.plugins.tooltip.callbacks = { label: (c) => ` ${c.dataset.label}: ${c.dataset.yAxisID === 'y1' ? FMT.pct(c.parsed.y) : FMT.num(c.parsed.y)}` };
    make('chForecast', cfg);
  }

  function topCustomers(g, t) {
    const list = KE.sortBy(g.cust.filter((x) => x.sales > 0), 'sales').slice(0, 10);
    empty('chCust', !list.length);
    if (!list.length) { if (inst.chCust) { inst.chCust.destroy(); delete inst.chCust; } return; }
    const act = FE.state.sets.cust;
    const cfg = {
      type: 'bar',
      data: { labels: list.map((x) => x.key), datasets: [{ label: 'Sales', data: list.map((x) => x.sales), backgroundColor: list.map((x) => (act.size && !act.has(x.key) ? t.sales + '55' : t.sales)), borderRadius: 4, barPercentage: 0.7 }] },
      options: Object.assign(baseOptions(t), { indexAxis: 'y', layout: { padding: { right: 150 } }, onClick: clickFilter('cust'), onHover: hoverCursor('cust'), scales: { x: Object.assign(axisStyle(t, (v) => FMT.compact(v)), { beginAtZero: true }), y: catAxis(t, 26) } }),
      plugins: [EndLabels]
    };
    cfg.options.plugins.legend = { display: false };
    cfg.options.plugins.endLabels = { fn: (i) => `${FMT.compact(list[i].sales)} · ${FMT.pct(list[i].contrib)} · ${list[i].invoices} inv` };
    cfg.options.plugins.tooltip.callbacks = { label: (c) => { const g2 = list[c.dataIndex]; return [` Sales: ${FMT.num(g2.sales)}`, ` Contribution: ${FMT.pct(g2.contrib)}`, ` Invoices: ${g2.invoices}`]; } };
    make('chCust', cfg);
  }

  function topProducts(g, mode, t) {
    const list = KE.sortBy(g.mat.filter((x) => (mode === 'qty' ? x.qty : x.sales) > 0), mode).slice(0, 10);
    empty('chProd', !list.length);
    if (!list.length) { if (inst.chProd) { inst.chProd.destroy(); delete inst.chProd; } return; }
    const act = FE.state.sets.mat;
    const cfg = {
      type: 'bar',
      data: { labels: list.map((x) => x.key), datasets: [{ label: mode === 'qty' ? 'Quantity' : 'Sales', data: list.map((x) => (mode === 'qty' ? x.qty : x.sales)), backgroundColor: list.map((x) => (act.size && !act.has(x.key) ? t.accent + '55' : t.accent)), borderRadius: 4, barPercentage: 0.7 }] },
      options: Object.assign(baseOptions(t), { indexAxis: 'y', layout: { padding: { right: 160 } }, onClick: clickFilter('mat'), onHover: hoverCursor('mat'), scales: { x: Object.assign(axisStyle(t, (v) => FMT.compact(v)), { beginAtZero: true }), y: catAxis(t, 28) } }),
      plugins: [EndLabels]
    };
    cfg.options.plugins.legend = { display: false };
    cfg.options.plugins.endLabels = { fn: (i) => (mode === 'qty' ? `${FMT.compact(list[i].qty)} · ${FMT.compact(list[i].sales)}` : `${FMT.compact(list[i].sales)} · ${FMT.compact(list[i].qty)} u`) + ` · ${FMT.pct(list[i].contrib)}` };
    cfg.options.plugins.tooltip.callbacks = { label: (c) => { const g2 = list[c.dataIndex]; return [` Sales: ${FMT.num(g2.sales)}`, ` Quantity: ${FMT.num(g2.qty)}`, ` Contribution: ${FMT.pct(g2.contrib)}`]; } };
    make('chProd', cfg);
  }

  function gauge(k, t) {
    const MAX = 150;
    const cfg = {
      type: 'doughnut',
      data: { labels: ['Critical (<75%)', 'At Risk (75-90%)', 'Near Target (90-100%)', 'Achieved (100%+)'], datasets: [{ data: [75, 15, 10, 50], backgroundColor: ['#ef4444', '#fb923c', '#facc15', '#10b981'], borderColor: t.surface, borderWidth: 2 }] },
      options: { responsive: true, maintainAspectRatio: false, rotation: -90, circumference: 180, cutout: '68%', layout: { padding: { top: 14, bottom: 4, left: 18, right: 18 } }, animation: { duration: 700 }, plugins: { legend: { display: false }, tooltip: { enabled: false }, gaugeNeedle: { value: k.ach, forecast: k.fAch, max: MAX } } },
      plugins: [GaugeNeedle]
    };
    make('chGauge', cfg);
  }

  /* ---------------- Public API ---------------- */
  function renderAll(S) {
    Chart.defaults.font.family = "'Inter','Segoe UI',system-ui,-apple-system,'Noto Sans Arabic',sans-serif";
    Chart.defaults.color = theme().text;
    const t = theme(), k = S.k, g = S.g;
    const safe = (name, fn) => { try { fn(); } catch (e) { console.error('Chart error [' + name + ']', e); UI.toast('warning', 'Chart "' + name + '" failed to render: ' + e.message); } };
    // keep division colours stable
    g.div.slice().sort((a, b) => String(a.key).localeCompare(String(b.key))).forEach((x) => colorFor(x.key));

    const execList = KE.rank(KE.sortBy(g.exec, S.rankBy));
    const supList = KE.rank(KE.sortBy(g.sup, 'ach'));
    const ktList = KE.rank(KE.sortBy(g.ktm, 'ach'));
    const klList = KE.rank(KE.sortBy(g.klm, 'ach'));

    safe('Sales vs Target by Division', () => divisionCombo(g, t));
    safe('Daily Sales Trend', () => dailyTrend(k, t));
    safe('Burn-up', () => burnUp(k, t));
    safe('Executive Ranking', () => hbarTargets('chExec', execList, { field: 'exec', highlight: true, rankNo: true }));
    safe('Supervisor Performance', () => hbarTargets('chSup', supList, { field: 'sup' }));
    safe('KT Manager', () => hbarTargets('chMgrKT', ktList, { field: 'ktm' }));
    safe('KL Manager', () => hbarTargets('chMgrKL', klList, { field: 'klm' }));
    safe('Top Customers', () => topCustomers(g, t));
    safe('Top Products', () => topProducts(g, S.prodMode, t));
    safe('Category Contribution', () => donut(g, k, t));
    safe('Pareto', () => pareto(g, t));
    safe('Forecast', () => forecastChart(g, k, t));
    safe('Gauge', () => gauge(k, t));
  }

  function resizeAll() {
    Object.keys(inst).forEach((id) => inst[id] && inst[id].resize());
    ['plotBurn', 'plotPareto'].forEach((id) => { const el = document.getElementById(id); if (el && el.data) Plotly.Plots.resize(el); });
  }

  global.FMT = FMT;
  global.CH = { renderAll, resizeAll, theme, colorFor, inst };
})(window);
