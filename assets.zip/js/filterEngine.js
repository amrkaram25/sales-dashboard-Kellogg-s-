/**
 * filterEngine.js
 * ----------------------------------------------------------------------------
 * Global, Power-BI style cross filtering.
 *  - Date range + 7 multi-select dimensions (searchable dropdowns)
 *  - Cascading option lists (each list is narrowed by all OTHER filters)
 *  - Chart click -> toggle filter (cross-highlight)
 *  - Active filter chips with one-click removal
 * Emits via FE.onChange(cb).
 */
(function (global) {
  'use strict';

  const DEFS = [
    { key: 'div',  field: 'div',  label: 'Division Name',        icon: 'bi-grid-3x3-gap' },
    { key: 'cust', field: 'cust', label: 'Sold to Party Name',   icon: 'bi-shop' },
    { key: 'mat',  field: 'mat',  label: 'Material Description', icon: 'bi-box-seam' },
    { key: 'exec', field: 'exec', label: 'KT Executive',         icon: 'bi-person-badge' },
    { key: 'sup',  field: 'sup',  label: 'KT Supervisor',        icon: 'bi-person-check' },
    { key: 'ktm',  field: 'ktm',  label: 'KT Manager',           icon: 'bi-person-gear' },
    { key: 'klm',  field: 'klm',  label: 'KL Manager',           icon: 'bi-briefcase' }
  ];
  const MAX_LIST = 400;

  const FE = {
    DEFS,
    data: [],
    meta: null,
    state: { from: null, to: null, sets: {} },
    _cb: [],
    _timer: null,

    onChange(cb) { this._cb.push(cb); },

    init(rows, meta) {
      this.data = rows; this.meta = meta;
      this.reset(true);
      this.buildUI();
      this.refreshOptions();
    },

    reset(silent) {
      this.state.from = null; this.state.to = null;
      DEFS.forEach((d) => { this.state.sets[d.key] = new Set(); });
      const f = document.getElementById('fDateFrom'), t = document.getElementById('fDateTo'), p = document.getElementById('fPreset');
      if (f) f.value = ''; if (t) t.value = ''; if (p) p.value = 'all';
      if (!silent) { this.refreshOptions(); this.renderChips(); this.emit(); }
    },

    isActive() { return !!(this.state.from || this.state.to || DEFS.some((d) => this.state.sets[d.key].size)); },

    /** Does a row pass all filters except (optionally) one key? */
    pass(r, skipKey) {
      const s = this.state;
      if (!r.isTarget || r.dt != null) {
        if (s.from != null || s.to != null) {
          if (r.dt == null) { if (!r.isTarget) return false; }
          else { if (s.from != null && r.dt < s.from) return false; if (s.to != null && r.dt > s.to) return false; }
        }
      }
      for (let i = 0; i < DEFS.length; i++) {
        const d = DEFS[i];
        if (d.key === skipKey) continue;
        const set = s.sets[d.key];
        if (set.size && !set.has(r[d.field])) return false;   // target rows have mat=null => dropped when material filter is active
      }
      return true;
    },

    apply() {
      const out = [];
      const rows = this.data;
      for (let i = 0; i < rows.length; i++) if (this.pass(rows[i])) out.push(rows[i]);
      return out;
    },

    toggle(key, value, additive) {
      const set = this.state.sets[key];
      if (!set) return;
      if (set.has(value)) set.delete(value);
      else { if (!additive && set.size && false) set.clear(); set.add(value); }
      this.changed();
    },

    setDateRange(fromMs, toMs) {
      this.state.from = fromMs; this.state.to = toMs;
      const f = document.getElementById('fDateFrom'), t = document.getElementById('fDateTo');
      if (f) f.value = fromMs ? DP.isoDate(fromMs) : '';
      if (t) t.value = toMs ? DP.isoDate(toMs) : '';
      this.changed();
    },

    changed() {
      clearTimeout(this._timer);
      this._timer = setTimeout(() => { this.refreshOptions(); this.renderChips(); this.emit(); }, 30);
    },
    emit() { this._cb.forEach((cb) => cb()); },

    /* ----------------------- UI ----------------------- */
    buildUI() {
      const host = document.getElementById('filterHost');
      host.innerHTML = '';
      DEFS.forEach((d) => {
        const wrap = document.createElement('div');
        wrap.className = 'ms dropdown';
        wrap.dataset.key = d.key;
        wrap.innerHTML = `
          <label class="ms-label"><i class="bi ${d.icon}"></i> ${d.label}</label>
          <button type="button" class="ms-btn" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
            <span class="ms-text">All</span><i class="bi bi-chevron-down ms-caret"></i>
          </button>
          <div class="dropdown-menu ms-panel">
            <div class="ms-search"><i class="bi bi-search"></i><input type="search" placeholder="Search ${d.label}..." autocomplete="off"></div>
            <div class="ms-actions"><a href="#" data-act="all">Select visible</a><a href="#" data-act="clear">Clear</a></div>
            <div class="ms-list"></div>
          </div>`;
        host.appendChild(wrap);
        const input = wrap.querySelector('input');
        input.addEventListener('input', () => this.renderList(d.key));
        wrap.querySelector('.ms-list').addEventListener('change', (e) => {
          const cb = e.target; if (!cb.matches('input[type=checkbox]')) return;
          const set = this.state.sets[d.key];
          if (cb.checked) set.add(cb.dataset.v); else set.delete(cb.dataset.v);
          this.changed();
        });
        wrap.querySelector('.ms-actions').addEventListener('click', (e) => {
          const a = e.target.closest('a'); if (!a) return; e.preventDefault();
          if (a.dataset.act === 'clear') this.state.sets[d.key].clear();
          else wrap.querySelectorAll('.ms-list input').forEach((cb) => this.state.sets[d.key].add(cb.dataset.v));
          this.changed();
        });
        wrap.addEventListener('shown.bs.dropdown', () => { input.focus(); });
      });

      // Date controls
      const f = document.getElementById('fDateFrom'), t = document.getElementById('fDateTo'), p = document.getElementById('fPreset');
      const toMs = (v) => (v ? Date.parse(v + 'T00:00:00Z') : null);
      f.onchange = () => { this.state.from = toMs(f.value); p.value = 'custom'; this.changed(); };
      t.onchange = () => { this.state.to = toMs(t.value); p.value = 'custom'; this.changed(); };
      p.onchange = () => {
        const max = this.meta.maxDt, min = this.meta.minDt; if (max == null) return;
        const D = 86400000, v = p.value;
        if (v === 'all') this.setDateRange(null, null);
        else if (v === 'mtd') { const d = new Date(max); this.setDateRange(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1), max); }
        else if (v === '7' || v === '14' || v === '30') this.setDateRange(max - (+v - 1) * D, max);
        p.value = v;
      };
      if (this.meta.minDt != null) { f.min = t.min = DP.isoDate(this.meta.minDt); f.max = t.max = DP.isoDate(this.meta.maxDt); }
    },

    refreshOptions() {
      DEFS.forEach((d) => {
        const counts = new Map();
        const rows = this.data;
        for (let i = 0; i < rows.length; i++) {
          const r = rows[i]; const v = r[d.field];
          if (v == null || !this.pass(r, d.key)) continue;
          counts.set(v, (counts.get(v) || 0) + (r.isTarget ? 0 : r.gsv));
        }
        this.state.sets[d.key].forEach((v) => { if (!counts.has(v)) counts.set(v, 0); });
        d._opts = Array.from(counts.entries()).sort((a, b) => String(a[0]).localeCompare(String(b[0]), undefined, { numeric: true, sensitivity: 'base' }));
        this.renderList(d.key);
      });
    },

    renderList(key) {
      const d = DEFS.find((x) => x.key === key);
      const wrap = document.querySelector(`.ms[data-key="${key}"]`); if (!wrap) return;
      const q = wrap.querySelector('input').value.trim().toLowerCase();
      const set = this.state.sets[key];
      let opts = d._opts || [];
      if (q) opts = opts.filter((o) => String(o[0]).toLowerCase().includes(q));
      const shown = opts.slice(0, MAX_LIST);
      const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
      wrap.querySelector('.ms-list').innerHTML = shown.map((o) =>
        `<label class="ms-item"><input type="checkbox" data-v="${esc(o[0])}" ${set.has(o[0]) ? 'checked' : ''}><span dir="auto">${esc(o[0])}</span></label>`).join('') +
        (opts.length > MAX_LIST ? `<div class="ms-more">${opts.length - MAX_LIST} more - refine your search</div>` : '') +
        (!opts.length ? '<div class="ms-more">No matching values</div>' : '');
      const txtEl = wrap.querySelector('.ms-text');
      txtEl.innerHTML = set.size === 0 ? 'All' : set.size === 1 ? esc(Array.from(set)[0]) : `${set.size} selected`;
      wrap.querySelector('.ms-btn').classList.toggle('active', set.size > 0);
    },

    renderChips() {
      const host = document.getElementById('chipHost');
      const chips = [];
      const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
      if (this.state.from || this.state.to) {
        chips.push(`<span class="chip" data-k="date"><i class="bi bi-calendar3"></i> ${this.state.from ? DP.isoDate(this.state.from) : '...'} → ${this.state.to ? DP.isoDate(this.state.to) : '...'} <button aria-label="Remove date filter">&times;</button></span>`);
      }
      DEFS.forEach((d) => this.state.sets[d.key].forEach((v) =>
        chips.push(`<span class="chip" data-k="${d.key}" data-v="${esc(v)}"><b>${d.label.replace(' Name', '').replace('Sold to Party', 'Customer')}:</b> <span dir="auto">${esc(v)}</span> <button aria-label="Remove">&times;</button></span>`)));
      host.innerHTML = chips.length ? chips.join('') : '<span class="chip-empty">No filters applied - click any chart element to cross-filter</span>';
      host.querySelectorAll('.chip button').forEach((b) => b.addEventListener('click', () => {
        const c = b.closest('.chip');
        if (c.dataset.k === 'date') { this.setDateRange(null, null); document.getElementById('fPreset').value = 'all'; }
        else { this.state.sets[c.dataset.k].delete(c.dataset.v); this.changed(); }
      }));
    }
  };

  global.FE = FE;
})(window);
